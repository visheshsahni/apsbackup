package com.aps.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aps.model.DashboardModel;
import com.aps.model.DateOfQuarter;
import com.aps.model.SQLDateFormatConverter;
import com.aps.repository.DashboardRepository;

@Service
public class DashboardService {

	@Autowired
	DashboardRepository dashboardrepository;

	// ----------------graphs---------------

	public List<Object> getGraphDataDeptforHR() throws ParseException {
		List<Object> req = new ArrayList<>();
		Calendar cal = Calendar.getInstance();
		Date today = new Date();
		cal.add(Calendar.YEAR, -1); // to get previous year add -1
		Date previousYear = cal.getTime();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String dateString = dateFormat.format(DateOfQuarter.getFirstDateOfQuarter(previousYear));
		java.sql.Date invoiceDate = SQLDateFormatConverter.convertDate("yyyy-MM-dd", dateString);
		System.out.println(invoiceDate);
		dashboardrepository.findGraphDataforHR(invoiceDate).forEach(req::add);
		return req;
	}
	// corpID obtained from session/login

	public String getroleforLogin() {
		return dashboardrepository.findroleBycorpIDforLogin(DashboardModel.getCorpId());
	}

	public Long getbenefitLevelforLogin() {
		return dashboardrepository.findbenefitLevelBycorpIDforLogin(DashboardModel.getCorpId());
	}

	public String getnameforHeader() {
		return dashboardrepository.findnamebycorpIDforHeader(DashboardModel.getCorpId());
	}

	public String getdesignationforHeader() {
		return dashboardrepository.finddesignationbycorpIDforHeader(DashboardModel.getCorpId());
	}

	public String getmanagerforManager() {
		return dashboardrepository.findBycorpIdforManager(DashboardModel.getCorpId());
	}

	// ----------------approver----------------

	public Long getPendingRequestforApprover() {
		return dashboardrepository.findByrequeststatusforApprover("submitted", DashboardModel.getCorpId());
	}

	public Long getShiftAllowanceDaysforApprover() {
		return dashboardrepository.findByallowanceTypeIDforApprover(1, DashboardModel.getCorpId());
	}

	public Long getOnCallDaysforApprover() {
		return dashboardrepository.findByallowanceTypeIDforApprover(2, DashboardModel.getCorpId());
	}

	// ----------------requester----------------

	public Long getPendingRequestforRequester() {
		return dashboardrepository.findByrequeststatusforRequester("submitted", DashboardModel.getCorpId());
	}

	public Long getApprovedRequestforRequester() {
		return dashboardrepository.findByrequeststatusforRequester("approved", DashboardModel.getCorpId());
	}

	public Long getRejectedRequestforRequester() {
		return dashboardrepository.findByrequeststatusforRequester("rejected", DashboardModel.getCorpId());
	}

	public Long getShiftAllowanceDaysforRequester() {
		return dashboardrepository.findByallowanceTypeIDforRequester(1, DashboardModel.getCorpId());
	}

	public Long getOnCallDaysforRequester() {
		return dashboardrepository.findByallowanceTypeIDforRequester(2, DashboardModel.getCorpId());
	}

	// ----------------HR----------------

	public Long findnumberOfDaysDeptID1forHR() {
		return dashboardrepository.findnumberOfDaysBydepartmentIdforHR(1);
	}

	public Long findnumberOfDaysDeptID2forHR() {
		return dashboardrepository.findnumberOfDaysBydepartmentIdforHR(2);
	}

	public Long findnumberOfDaysDeptID3forHR() {
		return dashboardrepository.findnumberOfDaysBydepartmentIdforHR(6);
	}

	public Long findnumberOfDaysDeptID4forHR() {
		return dashboardrepository.findnumberOfDaysBydepartmentIdforHR(7);
	}

	public Long findnumberOfDaysDeptID5forHR() {
		return dashboardrepository.findnumberOfDaysBydepartmentIdforHR(8);
	}

	// ----------------for reports-----------
	public List viewReport() {
		return dashboardrepository.viewReport();

	}

}
