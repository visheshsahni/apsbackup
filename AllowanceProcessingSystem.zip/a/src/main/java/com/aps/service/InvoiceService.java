package com.aps.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aps.domain.Invoice;
import com.aps.repository.InvoiceRepository;

@Service
public class InvoiceService {

	@Autowired
	private InvoiceRepository invoiceRepository;

	public void save(Invoice invoice) {
		invoiceRepository.save(invoice);
	}

	public Invoice getByPeriodId(Long periodID) {
		return invoiceRepository.getByPeriodId(periodID);
	}
}