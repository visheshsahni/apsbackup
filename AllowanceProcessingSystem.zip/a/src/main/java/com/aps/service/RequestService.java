package com.aps.service;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aps.domain.Department;
import com.aps.domain.Invoice;
import com.aps.domain.Request;
import com.aps.repository.RequestRepository;

@Service
public class RequestService {

	@Autowired
	RequestRepository requestrepository;
	@PersistenceContext
	private EntityManager eM;

	public List<Request> getAllRequest() {
		List<Request> req = new ArrayList<>();
		requestrepository.findAll().forEach(req::add);
		return req;
	}

	public void addRequest(Request request) {
		requestrepository.save(request);
	}

	public List<Request> getRequestId(String corp_id) {
		return requestrepository.getRequestId(corp_id);
	}

	public Iterable<Request> findRequestsByStatusAndDate(String status, java.util.Date cycleStartDate,
			java.util.Date cycleEndDate) {
		System.out.println("s"+cycleStartDate);
		System.out.println("s"+cycleEndDate);
		System.out.println("value"+requestrepository.findByStatusAndDate(status, cycleStartDate, cycleEndDate));
		return requestrepository.findByStatusAndDate(status, cycleStartDate, cycleEndDate);
	}

	public Iterable<Request> findAllNonInvoicedRequests(java.util.Date currentCycleDate) {
		String status = "invoiced";
		return requestrepository.findByNotStatus(status, currentCycleDate);
	}

	public List<Request> getRequestsForInvoice(Long invoiceDepartmentId, Date invoiceStartDate, Date invoiceEndDate) {
		return requestrepository.getRequestsToBeInvoiced(invoiceDepartmentId, invoiceStartDate, invoiceEndDate);
	}

	public void saveAll(List<Request> invoicedRequests) {
		requestrepository.save(invoicedRequests);
	}

	public List<Object> getInvoiceReport(Department department, Invoice invoice) {
		return requestrepository.findInvoiced(department, invoice);
	}

	public List<Object> getDepartmentReport(java.util.Date startDate, java.util.Date endDate,
			Request.request_Status requestStatus) {
		return requestrepository.getDepartmentReport(startDate, endDate, requestStatus);
	}

	public Iterable<HashMap<String, String>> getRequestToDownload(Invoice invoice) {
		return requestrepository.getRequestToDownload(invoice);
	}

	public Request findRequestById(Long requestID) {
		return requestrepository.getRequestById(requestID);
	}

	public List<Request> requesterView(String corpID) {
		return requestrepository.requesterViewRequests(corpID);
	}

	public Boolean getRequest(String corpID, Long allowanceTypeID, Timestamp periodStartDate) {
		if (requestrepository.getRequest(corpID, allowanceTypeID, periodStartDate) != null) {
			return false;
		} else {
			return true;
		}

	}

	// vishesh
	public List<Request> requesterView1(String corpID, java.util.Date periodStartDate, java.util.Date periodEndDate) {
		return requestrepository.requesterViewRequests1(corpID, periodStartDate, periodEndDate);
	}

	public List<Request> getTeamReport(String corpId, Date periodStartDate, Date periodEndDate) {
		return requestrepository.getTeamReport(corpId, periodStartDate, periodEndDate);
	}

	public void update(Request request) {
		// TODO Auto-generated method stub
		requestrepository.save(request);
		
	}

}
