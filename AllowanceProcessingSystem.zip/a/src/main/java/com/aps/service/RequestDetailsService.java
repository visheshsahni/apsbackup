package com.aps.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aps.domain.RequestDetails;
import com.aps.repository.RequestDetailsRepository;

@Service
public class RequestDetailsService {

	@Autowired
	RequestDetailsRepository requestdetailsrepository;

	public RequestDetails getRequestDetails(Long id) {

		return requestdetailsrepository.getOneRequestDetailsByRequestID(id);

	}
	public List<RequestDetails> getAllRequestDetailsByRequestID(Long requestId){
		return requestdetailsrepository.getRequestDetailsByRequestID(requestId);
	}

	public List<RequestDetails> getAllRequestDetails() {
		List<RequestDetails> reqd = new ArrayList<>();
		requestdetailsrepository.findAll().forEach(reqd::add);
		return reqd;
	}

	public void addRequestDetails(RequestDetails requestdetails) {
		requestdetailsrepository.save(requestdetails);

	}

	public List<Date> getDatesByID(Long id) {

		return requestdetailsrepository.getDatesByID(id);
	}
	public void deleteRequestDetails(List<RequestDetails> req){
		requestdetailsrepository.delete(req);
	}

}
