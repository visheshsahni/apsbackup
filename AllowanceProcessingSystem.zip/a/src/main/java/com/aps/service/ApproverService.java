package com.aps.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aps.domain.Request;
import com.aps.repository.ApproverRepository;

@Service
public class ApproverService {
	@Autowired
	ApproverRepository approverrepository;
	public Iterable<Request> requestChange(String corpID) {
		return approverrepository.requesterChangeRequests(corpID);
	}
	public Iterable<Request> changeStatus(Long requestID) {
		return approverrepository.approverChangeStatus(requestID);
	}
}
