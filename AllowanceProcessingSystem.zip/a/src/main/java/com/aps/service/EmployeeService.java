package com.aps.service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aps.domain.Employee;
import com.aps.domain.Login;
import com.aps.model.DashboardModel;
import com.aps.model.EmployeeModel;
import com.aps.repository.EmployeeRepository;
import com.aps.repository.LoginRepository;

@Service
public class EmployeeService {

	@Autowired
	EmployeeRepository employeeRepository;

	@Autowired
	LoginRepository loginRepository;

	@Autowired
	DepartmentService departmentService;

	public List<Employee> getAllEmployee() {
		List<Employee> emp = new ArrayList<>();
		employeeRepository.findAll().forEach(emp::add);
		return emp;

	}

	public Boolean getValidUser(String CorpId, String plain_password) {
		String hashed = loginRepository.getValidUser(CorpId);
		Boolean status=employeeRepository.getStatus(CorpId);
		if (BCrypt.checkpw(plain_password, hashed) && status) {
			return true;
		} else
			return false;

	}

	public List<Employee> getEmployeeUnder(Employee emp) {

		List<Employee> empunder = new ArrayList<Employee>();
		List<Employee> empall = new ArrayList<Employee>();
		employeeRepository.findAll().forEach(empall::add);
		for (int i = 0; i < empall.size(); i++) {

			Employee e = empall.get(i);

			if ((e.getManager()) != null) {

				String cid = (e.getManager()).getCorpId();

				if (cid.equals(emp.getCorpId())) {

					empunder.add(e);
					empunder.addAll(getEmployeeUnder(e));

				}

			}
		}
		return empunder;

	}

	public Employee getEmployeeById(String corpId) {
		Employee emp1 = new Employee();
		emp1 = employeeRepository.findOne(corpId);
		return emp1;

	}

	public void addEmployee(Employee employee) {
		employee.setStartDate(java.sql.Date.valueOf(LocalDate.now()));
		employeeRepository.save(employee);

	}

	public ArrayList<Employee> getEmployeeObjectList(List<EmployeeModel> listEmpModel, boolean comingFromAdd) {
		Date startDate = java.sql.Date.valueOf(LocalDate.now());
		ArrayList<Employee> employeeList = new ArrayList<Employee>();

		for (int i = 0; i < listEmpModel.size(); i++) {
			Employee e = new Employee();
			e.setCorpId(listEmpModel.get(i).getCorpId());
			e.setName(listEmpModel.get(i).getName());
			e.setEmailId(listEmpModel.get(i).getEmailId());
			e.setRole(listEmpModel.get(i).getRole());
			e.setBenefitLevel(listEmpModel.get(i).getBenefitLevel());
			e.setPhoneNo(listEmpModel.get(i).getPhoneNo());
			e.setStatus(true);
			if (comingFromAdd == true) {
				e.setStatus(true);
			} else
				e.setStatus(listEmpModel.get(i).getStatus());
			e.setStartDate(startDate);
			e.setUpdatedBy(DashboardModel.getCorpId());
			e.setDesignation(listEmpModel.get(i).getDesignation());
			if (listEmpModel.get(i).getManagerId().isEmpty()) {
				e.setManager(employeeRepository.getEmployeeById("A000000").get(0));
			} else
				e.setManager(employeeRepository.getEmployeeById(listEmpModel.get(i).getManagerId()).get(0));

			e.setDepartmentId(departmentService.findById(listEmpModel.get(i).getDepartmentId()));
			employeeList.add(e);
		}
		return employeeList;
	}

	public void checkForDuplicates(List<Employee> list_emp) {
		for (int i = 0; i < list_emp.size(); i++) {
			Employee existing_emp = employeeRepository.findExistingEmployee(list_emp.get(i).getCorpId());
			if (existing_emp == null) {
				addEmployee(list_emp.get(i));
			} else {
				if (existing_emp.getBenefitLevel().equals(list_emp.get(i).getBenefitLevel())
						&& existing_emp.getCorpId().equals(list_emp.get(i).getCorpId())
						&& existing_emp.getDepartmentId().equals(list_emp.get(i).getDepartmentId())
						&& existing_emp.getDesignation().equals(list_emp.get(i).getDesignation())
						&& existing_emp.getEmailId().equals(list_emp.get(i).getEmailId())
						&& existing_emp.getManager().equals(list_emp.get(i).getManager())
						&& existing_emp.getName().equals(list_emp.get(i).getName())
						&& existing_emp.getRole().equals(list_emp.get(i).getRole())
						&& existing_emp.getPhoneNo().equals(list_emp.get(i).getPhoneNo())
						&& existing_emp.isStatus() == list_emp.get(i).isStatus()) {
					// same record, do nothing.
				} else
					updateEmployee(list_emp.get(i));
			}
		}
	}

	public void updateEmployee(Employee employee) {
		employee.setStartDate(java.sql.Date.valueOf(LocalDate.now()));
		employeeRepository.updateEmployee(employee.getName(), employee.getDepartmentId().getDepartmentId(),
				employee.getManager().getCorpId(), employee.getRole(), employee.getEmailId(),
				employee.getBenefitLevel(), employee.getPhoneNo(), employee.isStatus(), employee.getStartDate(),
				employee.getUpdatedBy(), employee.getDesignation(), employee.getCorpId());
	}

	public Employee checkUser(String corpId) {
		return employeeRepository.checkUser(corpId);
	}

	public Boolean reset(String corp_id, String plain_password) {
		// TODO Auto-generated method stub
		String password = BCrypt.hashpw(plain_password, BCrypt.gensalt());
		if (loginRepository.reset(corp_id, password) == 1)
			return true;
		else
			return false;

	}

	public void addUser(Login login) {
		// TODO Auto-generated method stub
		loginRepository.save(login);

	}

	public Boolean authorize(String corp_id) {
		// TODO Auto-generated method stub
		Boolean value = loginRepository.authorize(corp_id);
		return value;
	}

	public void selfDestructing(String corp_id) {
		// TODO Auto-generated method stub
		loginRepository.selfDestructing(corp_id, false);

	}

	public Login checkLogger(String corp_id) {
		return loginRepository.checkLogger(corp_id);

	}

	public List<Employee> getEmployeeByDeptId(String departmentId) {
		Long temp;
		temp = Long.parseLong(departmentId);
		return employeeRepository.getEmployeeByDeptId(temp);
	}
}
