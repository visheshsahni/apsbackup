package com.aps.service;

import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aps.domain.Department;
import com.aps.domain.Employee;
import com.aps.model.DashboardModel;
import com.aps.repository.DepartmentRepository;

@Service
public class DepartmentService {

	@Autowired
	DepartmentRepository departmentrepository;

	@Autowired
	private DepartmentService departmentservice;

	@Autowired
	private EmployeeService employeeservice;

	public List<Department> getAllDepartments() {
		List<Department> dept = new ArrayList<>();
		departmentrepository.findAll().forEach(dept::add);
		return dept;
	}

		public void addDepartment(Department dep) {
		
			/*dep.setDepartmentId(null);*/
		departmentrepository.save(dep);
	}

	public List<Department> findByName(String departmentName) {
		List<Department> dept = new ArrayList<>();
		departmentrepository.findByName(departmentName).forEach(dept::add);

		return dept;
	}

	public List<Department> findByCode(String departmentCode) {
		List<Department> dept = new ArrayList<>();
		departmentrepository.findByCode(departmentCode).forEach(dept::add);

		return dept;
	}

	public List<Department> findSubDept(Long departmentId) {
		List<Department> dept = new ArrayList<>();
		departmentrepository.findSubDept(departmentId).forEach(dept::add);

		return dept;

	}

	public Department getDepartmentDetails(String departmentCode) {
		return departmentrepository.getDepartmentDetails(departmentCode);
	}

	public Iterable<Department> getActiveDepartments() {
		return departmentrepository.getActiveParentDepartments();
	}

	public Iterable<Department> getAllActiveDepartments() {
		return departmentrepository.getAllActiveDepartments();
	}

	public Iterable<Department> getDepartmentCodes(Long departmentId) {
		return departmentrepository.getDepartmentCodes(departmentId);
	}

	public Department getDepartmentByName(String departmentName) {
		return departmentrepository.getDepartmentByName(departmentName);
	}

	public Department findById(Long deptId) {
		return departmentrepository.findById(deptId);
	}

	public Iterable<Department> getActiveAndInactiveDepartments() {
		return departmentrepository.getActiveAndInactiveParentDepartments();
	}

	public int findTotalSubDepartments(int departmentId) {
		return departmentrepository.findTotalSubDepartments(departmentId);
	}

	public int deleteDepartment(int departmentId) {
		return departmentrepository.deleteDepartment(departmentId);
	}

	public void modifyEmployee(String jsonString) throws ParseException {
		JSONParser jsonParser = new JSONParser();
		JSONObject obj = (JSONObject) jsonParser.parse(jsonString);
		String departmentId = (String) obj.get("departmentId");
		String departmentCode = (String) obj.get("departmentCode");
		int did = Integer.parseInt(departmentId);
		// System.out.println(departmentId + " "+departmentCode);

		List<Employee> employeeList = employeeservice.getEmployeeByDeptId(departmentId);
		Department dept = departmentservice.getDepartmentDetails(departmentCode);
		for (Employee emp : employeeList) {
			emp.setDepartmentId(dept);
			emp.setUpdatedBy(DashboardModel.getCorpId());
		}
		employeeservice.checkForDuplicates(employeeList);
		departmentservice.deleteDepartment(did);
	}
}
