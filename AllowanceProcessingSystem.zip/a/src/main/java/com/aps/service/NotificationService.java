package com.aps.service;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServlet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.aps.controller.Security;
import com.aps.repository.LoginRepository;

@Service
public class NotificationService {
	
	
	private JavaMailSender javaMailSender;
	@Autowired
	LoginRepository loginRepository;

	// private Security security;

	@Autowired
	public NotificationService(JavaMailSender javaMailSender) {
		this.javaMailSender = javaMailSender;
	}

	public void sendNotification(String email, String corpId) throws Exception {
		// send email
		SimpleMailMessage mail = new SimpleMailMessage();
		mail.setTo(email);
		mail.setFrom("companyncu@gmail.com");
		Date date = new Date();
		String cd= new SimpleDateFormat("yyyy-MM-dd").format(date);
		System.out.println(cd);
		String value=corpId+cd;
		String text = Security.encrypt(Security.key, Security.initVector, value);
		System.out.println("value :" +text);
		mail.setSubject("Notification");
		loginRepository.selfDestructing(corpId, true);
		String textMail = "Mail send "
				+ "<a href=\"http://localhost:8100/setpassword.html?v="+text+"\">reset link</a>";
		mail.setText(textMail);
		javaMailSender.send(mail);
	}

}
