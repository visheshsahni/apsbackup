package com.aps.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateOfQuarter {
	public static Date getFirstDateOfQuarter(Date date) throws ParseException {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		dateFormat.setTimeZone(cal.getTimeZone());
		cal.setTime(date);
		System.out.println("dare" + cal.get(Calendar.MONTH) / 3 * 3);
		System.out.println("date" + ((cal.get(Calendar.MONTH) / 3 * 3) - 1));
		cal.set(Calendar.MONTH, cal.get(Calendar.MONTH) / 3 * 3);
		cal.set(Calendar.DAY_OF_MONTH, 1);
		cal.set(Calendar.HOUR_OF_DAY, 00);
		cal.set(Calendar.MINUTE, 00);
		cal.set(Calendar.SECOND, 00);
		//cal.add(Calendar.DATE, -1);
		System.out.println("dateofquarter : " + cal.getTime());
		System.out.println("simple" + dateFormat.format(cal.getTime()));
		Date parsedDate = dateFormat.parse(dateFormat.format(cal.getTime()));
		return parsedDate;
	}

	public static Date getLastDateOfQuarter(Date date) throws ParseException {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		dateFormat.setTimeZone(cal.getTimeZone());
		cal.setTime(date);
		System.out.println("dare" + cal.get(Calendar.MONTH) / 3 * 3);
		// System.out.println("date"+((cal.get(Calendar.MONTH)/3 * 3)-1));
		cal.set(Calendar.MONTH, cal.get(Calendar.MONTH) / 3 * 3 + 2);
		cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
		cal.set(Calendar.HOUR_OF_DAY, 00);
		cal.set(Calendar.MINUTE, 00);
		cal.set(Calendar.SECOND, 00);
		//cal.add(Calendar.DATE, +1);
		System.out.println("dateofquarter : " + cal.getTime());
		System.out.println("simple" + dateFormat.format(cal.getTime()));
		Date parsedDate = dateFormat.parse(dateFormat.format(cal.getTime()));
		return parsedDate;
	}
/*	public static Date onegetFirstDateOfQuarter(Date date) {
		Calendar cal = Calendar.getInstance();
	    cal.setTime(date);
	    cal.set(Calendar.MONTH, cal.get(Calendar.MONTH)/3 * 3);
	    cal.set(Calendar.DAY_OF_MONTH, 1);
	    cal.set(Calendar.HOUR_OF_DAY, 00);
	    cal.set(Calendar.MINUTE, 00);
	    cal.set(Calendar.SECOND, 00);
		return cal.getTime();
	}

	public static Date onegetLastDateOfQuarter(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.MONTH, cal.get(Calendar.MONTH) / 3 * 3 + 2);
		cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
		cal.set(Calendar.HOUR_OF_DAY, 00);
	    cal.set(Calendar.MINUTE, 00);
	    cal.set(Calendar.SECOND, 00);
	    return cal.getTime();
	}*/
	
}
