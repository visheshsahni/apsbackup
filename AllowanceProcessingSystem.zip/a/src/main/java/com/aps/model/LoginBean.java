package com.aps.model;

import java.io.Serializable;

public class LoginBean implements Serializable{

}
