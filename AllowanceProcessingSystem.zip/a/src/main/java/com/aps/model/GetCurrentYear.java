package com.aps.model;

import java.time.Year;
import java.util.HashMap;

import org.json.simple.JSONObject;

public class GetCurrentYear {

	public static JSONObject getYear() {
		int currentYear = Year.now().getValue();
		HashMap<String, Object> hashCurrentYear = new HashMap<String, Object>();
		hashCurrentYear.put("year", currentYear);
		JSONObject jsonCurrentYear = new JSONObject(hashCurrentYear);
		return jsonCurrentYear;
	}
}
