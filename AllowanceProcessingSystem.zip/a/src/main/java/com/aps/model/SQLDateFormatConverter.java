package com.aps.model;

import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class SQLDateFormatConverter {

	public static Date convertCurrentDateFormatter(String format) throws ParseException {
		DateFormat dateFormat = new SimpleDateFormat(format);
		String dateString = dateFormat.format(new java.util.Date());
		java.util.Date date = dateFormat.parse(dateString);
		return new Date(date.getTime());
	}

	public static Date convertDate(String format, String time) throws ParseException {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
		java.util.Date date = simpleDateFormat.parse(time);
		return new Date(date.getTime());
	}
}
