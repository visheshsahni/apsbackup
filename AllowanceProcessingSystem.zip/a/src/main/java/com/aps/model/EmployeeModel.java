package com.aps.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EmployeeModel {

	private String corpId;
	private Long departmentId;
	private String name;
	private String managerId;
	private String emailId;
	private String role;
	private Long benefitLevel;
	private Long phoneNo;
	private Boolean status;
	private String designation;

	public EmployeeModel() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeModel(String corpId, Long departmentId, String name, String managerId, String emailId, String role,
			Long benefitLevel, Long phoneNo, Boolean status, String designation) {
		super();
		this.corpId = corpId;
		this.departmentId = departmentId;
		this.name = name;
		this.managerId = managerId;
		this.emailId = emailId;
		this.role = role;
		this.benefitLevel = benefitLevel;
		this.phoneNo = phoneNo;
		this.status = status;
		this.designation = designation;
	}

	public String getCorpId() {
		return corpId;
	}

	public void setCorpId(String corpId) {
		this.corpId = corpId;
	}

	public Long getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Long departmentId) {
		this.departmentId = departmentId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getManagerId() {
		return managerId;
	}

	public void setManagerId(String managerId) {
		this.managerId = managerId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Long getBenefitLevel() {
		return benefitLevel;
	}

	public void setBenefitLevel(Long benefitLevel) {
		this.benefitLevel = benefitLevel;
	}

	public Long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}
	
	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}
}