package com.aps.model;

public class DashboardModel {

	private static String corpId;

	public DashboardModel() {
		super();
		// TODO Auto-generated constructor stub
	}

	public static String getCorpId() {
		return corpId;
	}

	public static void setCorpId(String corpId) {
		DashboardModel.corpId = corpId;
	}

}
