package com.aps.model;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.servlet.view.document.AbstractXlsxView;

import com.aps.domain.AllowanceReport;

public class AllowanceExcelView extends AbstractXlsxView{

	@Override
	protected void buildExcelDocument(Map<String, Object> model, Workbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		response.setHeader("Content-Disposition", "attachment; filename=\"Allowance Report.xlsx\"");

		@SuppressWarnings("unchecked")
		List<AllowanceReport> allowanceReports = (List<AllowanceReport>) model.get("report");
		Sheet sheet = workbook.createSheet("Allowance Report");

		Row header = sheet.createRow(0);
		header.createCell(0).setCellValue("Corp ID");
		header.createCell(1).setCellValue("Department Code");
		header.createCell(2).setCellValue("Amount");

		int rowNum = 1;
		for (AllowanceReport allowance : allowanceReports) {
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(allowance.getCorpId());
			row.createCell(1).setCellValue(allowance.getDepartmentCode());
			row.createCell(2).setCellValue(allowance.getAmount());
		}
	}

}
