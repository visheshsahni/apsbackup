package com.aps.model;

import java.util.Calendar;
import java.util.Date;

public class MonthDates {

	public static Date getFirstDate(String month, String year) {
		int monthInt = 0;
		int yearInt = Integer.parseInt(year);

		String[] monthNames = { "January", "February", "March", "April", "May", "June", "July", "August", "September",
				"October", "November", "December" };
		for (int i = 0; i < 12; i++) {
			if (monthNames[i].equalsIgnoreCase(month)) {
				monthInt = i;
			}
		}

		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.YEAR, yearInt);
		calendar.set(Calendar.MONTH, monthInt);

		calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMinimum(Calendar.DAY_OF_MONTH));
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		return calendar.getTime();
	}

	public static Date getEndDate(String month, String year) {
		int monthInt = 0;
		int yearInt = Integer.parseInt(year);

		String[] monthNames = { "January", "February", "March", "April", "May", "June", "July", "August", "September",
				"October", "November", "December" };
		for (int i = 0; i < 12; i++) {
			if (monthNames[i].equalsIgnoreCase(month)) {
				monthInt = i;
			}
		}

		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.YEAR, yearInt);
		calendar.set(Calendar.MONTH, monthInt);

		calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 59);
		calendar.set(Calendar.MILLISECOND, 999);
		return calendar.getTime();
	}
}
