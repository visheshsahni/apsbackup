package com.aps;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AllowanceProcessingApplication {

	public static void main(String args[]) {
		SpringApplication.run(AllowanceProcessingApplication.class, args);
	}

}