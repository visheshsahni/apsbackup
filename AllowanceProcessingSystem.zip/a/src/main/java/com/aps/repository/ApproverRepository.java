package com.aps.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.aps.domain.Request;

@Repository
public interface ApproverRepository extends CrudRepository<Request, Long>{
	@Query(value = "SELECT * FROM request r WHERE r.request_id=?1 limit 1", nativeQuery = true)
	List<Request> approverChangeStatus(Long requestID);
	
	@Query(value = "SELECT * FROM request r JOIN employee e ON r.corp_id = e.corp_id WHERE e.manager_id = ?1 AND r.request_status='submitted'", nativeQuery = true)
	List<Request> requesterChangeRequests(String corpID);
}
