package com.aps.repository;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.aps.domain.Department;
import com.aps.domain.Invoice;
import com.aps.domain.Request;


@Repository
@Transactional
public interface RequestRepository extends CrudRepository<Request, Long> {

	// ----------------approver----------------

	@Query(value = "SELECT COUNT(request.request_status) FROM request, employee WHERE request.request_status=?1 AND employee.manager_id=?2 AND request.corp_id=employee.corp_id", nativeQuery = true)
	Long findByrequeststatusforApprover(String requeststatus, String corpID);

	@Query(value = "SELECT COUNT(*) FROM employee WHERE manager_id=?1", nativeQuery = true)
	String findBycorpIdforManager(String corpID);

	@Query(value = "SELECT SUM(request.number_of_days) FROM request, employee WHERE request.allowance_type_id=?1 AND employee.manager_id=?2 AND request.corp_id=employee.corp_id", nativeQuery = true)
	Long findByallowanceTypeIDforApprover(int allowanceTypeID, String corpID);

	// ----------------requester----------------

	@Query(value = "SELECT COUNT(request.request_status) FROM request, employee WHERE request.request_status=?1 AND employee.corp_id=?2 AND request.corp_id=employee.corp_id", nativeQuery = true)
	Long findByrequeststatusforRequester(String requeststatus, String corpID);

	@Query(value = "SELECT SUM(request.number_of_days) FROM request, employee WHERE request.allowance_type_id=?1 AND employee.corp_id=?2 AND request.corp_id=employee.corp_id", nativeQuery = true)
	Long findByallowanceTypeIDforRequester(int allowanceTypeID, String corpID);

	// ----------------HR----------------
	@Query(value = "SELECT SUM(request.number_of_days) FROM request,employee WHERE employee.dept_id=?1 AND request.corp_id=employee.corp_id", nativeQuery = true)
	Long findnumberOfDaysBydepartmentIdforHR(int departmentId);

	@Query(value = "SELECT * FROM request r JOIN employee e ON r.corp_id = e.corp_id JOIN department d ON e.dept_id = d.dept_id WHERE (e.dept_id = ?1 OR d.parent_dept_id = ?1) AND r.request_status = 'approved' AND r.period_start_date >= ?2 AND period_end_date <= ?3", nativeQuery = true)
	List<Request> getRequestsToBeInvoiced(Long invoiceDepartmentId, Date invoiceStartDate, Date invoiceEndDate);

	@Query(value = "SELECT * FROM request r WHERE r.request_status= ?1 AND r.period_start_date >= ?2 AND r.period_end_date <= ?3 ORDER BY r.allowance_type_id, r.corp_id", nativeQuery = true)
	List<Request> findByStatusAndDate(String status, Date cycleStartDate, Date cycleEndDate);

	@Query(value = "SELECT * FROM request r WHERE NOT r.request_status = 'saved' AND NOT r.request_status = 'rejected' AND NOT r.request_status = ?1 AND r.period_start_date >= ?2 ORDER BY r.allowance_type_id, r.request_status, r.corp_id", nativeQuery = true)
	List<Request> findByNotStatus(String status, Date currentCycleDate);

	@Query(value = "SELECT new map(d.departmentName AS DepartmentName, a.typeName AS AllowanceType, SUM(r.numberOfDays) AS NumberOfDays, SUM(r.amount) AS Amount) FROM request AS r INNER JOIN r.corpID AS e INNER JOIN e.departmentId AS d INNER JOIN r.allowanceTypeID AS a WHERE (e.departmentId= ?1 OR d.parentDepartmentId= ?1) AND r.invoiceID= ?2 GROUP BY a.allowanceTypeID, d.departmentId ORDER BY d.departmentName")
	List<Object> findInvoiced(Department department, Invoice invoice);
	
	@Query(value = "SELECT new map(SUM(r.amount) AS Amount, SUM(r.numberOfDays) AS NumberOfDays, a.typeName AS AllowanceType, d.departmentName AS DepartmentName) FROM request AS r INNER JOIN r.corpID AS e INNER JOIN e.departmentId AS d INNER JOIN r.allowanceTypeID AS a WHERE r.periodStartDate>= ?1 AND r.periodEndDate<= ?2 AND r.requeststatus= ?3 GROUP BY a.allowanceTypeID, d.departmentId ORDER BY d.departmentName")
	List<Object> getDepartmentReport(Date startDate, Date endDate, Request.request_Status requestStatus);

	@Query(value = "SELECT new map(SUM(r.amount) AS amount, e.corpId AS corpId, d.departmentCode AS departmentCode) FROM request AS r INNER JOIN r.corpID AS e INNER JOIN e.departmentId AS d WHERE r.invoiceID = ?1 GROUP BY r.corpID ORDER BY r.corpID")
	Iterable<HashMap<String, String>> getRequestToDownload(Invoice invoice);
	
	@Query(value="Select * from request where corp_id=?1 AND period_start_date=?2 AND period_end_date=?3",nativeQuery=true)
	List<Request> getTeamReport(String corpId,Date periodStartDate,Date periodEndDate);
	

	// -------------LoginRole-------------

	@Query(value = "SELECT role FROM employee WHERE corp_id=?1", nativeQuery = true)
	String findroleBycorpIDforLogin(String corpID);

	@Query(value = "SELECT benefit_level FROM employee WHERE corp_id=?1", nativeQuery = true)
	Long findbenefitLevelBycorpIDforLogin(String corpID);

	@Query(value = "SELECT emp_name FROM employee WHERE corp_id=?1", nativeQuery = true)
	String findnamebycorpIDforHeader(String corpID);

	@Query(value = "SELECT designation FROM employee WHERE corp_id=?1", nativeQuery = true)
	String finddesignationbycorpIDforHeader(String corpID);

	@Query(value = "SELECT * FROM request r WHERE r.corp_id= ?1", nativeQuery = true)
	List<Request> requesterViewRequests(String corpID);
	
	//vishesh
	@Query(value = "SELECT * FROM request r WHERE r.corp_id= ?1 AND r.period_start_date>= ?2 AND r.period_end_date<= ?3", nativeQuery = true)
	List<Request> requesterViewRequests1(String corpID, Date periodStartDate,Date periodEndDate);

	@Query(value = "SELECT * FROM request r WHERE r.request_id=?1 limit 1", nativeQuery = true)
	Request getRequestById(Long requestID);
	
	@Query(value="Select * from request r where r.corp_id=?1 and r.allowance_type_id=?2 and r.period_start_date=?3",nativeQuery=true)
	Request getRequest(String corpID,Long allowanceTypeID,Timestamp periodStartDate);
	
	@Query(value = "select * from request r where status_start_date=(select max(status_start_date) from request where corp_id=?1);", nativeQuery = true)
	List<Request> getRequestId(String corp_id);

}
