package com.aps.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.aps.domain.Request;

@Repository
public interface DashboardRepository extends CrudRepository<Request, Long> {

	// -----------------graphs------------------

	//@Query(value = "Select new map (d.departmentId as did,p.periodName as pid,sum(i.totalAmount + i.adjustments) as ta) FROM invoice as i inner join i.departmentID as d inner join i.periodID as p where i.generatedDate >= ?1 group by p.periodName,d.departmentId order by p.periodName,d.departmentId")
	@Query(value = "Select new map (d.departmentId as did,p.periodName as pid,p.year as pyear,p.periodID,sum(i.totalAmount + i.adjustments) as ta) FROM invoice as i inner join i.departmentID as d inner join i.periodID as p where i.generatedDate >= ?1 group by p.periodID,p.periodName,p.year,d.departmentId order by p.periodID,d.departmentId")
	List<Object> findGraphDataforHR(Date date);

	// ----------------approver----------------

	@Query(value = "SELECT COUNT(request.request_status) FROM request, employee WHERE request.request_status=?1 AND employee.manager_id=?2 AND request.corp_id=employee.corp_id AND MONTH(request.status_start_date)=MONTH(CURRENT_DATE())", nativeQuery = true)
	Long findByrequeststatusforApprover(String requeststatus, String corpID);

	@Query(value = "SELECT COUNT(*) FROM employee WHERE manager_id=?1", nativeQuery = true)
	String findBycorpIdforManager(String corpID);

	@Query(value = "SELECT SUM(request.number_of_days) FROM request, employee WHERE request.allowance_type_id=?1 AND employee.manager_id=?2 AND request.corp_id=employee.corp_id AND MONTH(request.status_start_date)=MONTH(CURRENT_DATE())", nativeQuery = true)
	Long findByallowanceTypeIDforApprover(int allowanceTypeID, String corpID);

	// ----------------requester----------------

	@Query(value = "SELECT COUNT(request.request_status) FROM request, employee WHERE request.request_status=?1 AND employee.corp_id=?2 AND request.corp_id=employee.corp_id AND MONTH(request.status_start_date)=MONTH(CURRENT_DATE())", nativeQuery = true)
	Long findByrequeststatusforRequester(String requeststatus, String corpID);

	@Query(value = "SELECT SUM(request.number_of_days) FROM request, employee WHERE request.allowance_type_id=?1 AND employee.corp_id=?2 AND request.corp_id=employee.corp_id AND MONTH(request.status_start_date)=MONTH(CURRENT_DATE())", nativeQuery = true)
	Long findByallowanceTypeIDforRequester(int allowanceTypeID, String corpID);

	// ----------------HR----------------
	@Query(value = "SELECT SUM(request.number_of_days) FROM request,employee WHERE employee.dept_id=?1 AND request.corp_id=employee.corp_id AND MONTH(request.status_start_date)=MONTH(CURRENT_DATE())", nativeQuery = true)
	Long findnumberOfDaysBydepartmentIdforHR(int departmentId);

	// -------------LoginRole-------------

	@Query(value = "SELECT role FROM employee WHERE corp_id=?1", nativeQuery = true)
	String findroleBycorpIDforLogin(String corpID);

	@Query(value = "SELECT benefit_level FROM employee WHERE corp_id=?1", nativeQuery = true)
	Long findbenefitLevelBycorpIDforLogin(String corpID);

	@Query(value = "SELECT emp_name FROM employee WHERE corp_id=?1", nativeQuery = true)
	String findnamebycorpIDforHeader(String corpID);

	@Query(value = "SELECT designation FROM employee WHERE corp_id=?1", nativeQuery = true)
	String finddesignationbycorpIDforHeader(String corpID);

	// --------------for Reports--------------
	// @Query(value="SELECT
	// e.corpId,d.deptartmentName,e.name,e.manager,e.benefitLevel,r.requestID,a.typeName,i.invoiceID,r.periodStartDate,r.periodEndDate,r.numberOfDays,r.submittedDate,i.totalAmount,r.requeststatus
	// FROM com.aps.domain.Employee e,com.aps.domain.Request
	// r,com.aps.domain.Invoice i,com.aps.domain.AllowanceType
	// a,com.aps.domain.Departmment d WHERE e.corpId=r.corpId AND
	// r.invoiceID=i.invoiceID AND e.departmentId=d.departmentId AND
	// r.allowanceTypeID=a.allowanceTypeID ")
	@Query(value = "select * from employee inner join department ", nativeQuery = true)
	List viewReport();

}
