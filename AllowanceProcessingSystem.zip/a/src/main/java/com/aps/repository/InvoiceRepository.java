package com.aps.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.aps.domain.Invoice;

@Repository
public interface InvoiceRepository extends CrudRepository<Invoice, Long> {

	@Query(value = "SELECT * FROM invoice i WHERE i.status = 1 AND i.period_id = ?1", nativeQuery = true)
	Invoice getByPeriodId(Long periodID);

}
