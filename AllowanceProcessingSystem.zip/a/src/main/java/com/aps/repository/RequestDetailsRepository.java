package com.aps.repository;



import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.aps.domain.RequestDetails;

@Repository
public interface RequestDetailsRepository extends CrudRepository<RequestDetails, Long> {

	@Query(value = "Select * from request_details where request_id=?1 limit 1", nativeQuery = true)
	RequestDetails getOneRequestDetailsByRequestID(Long id);
	
	@Query(value="Select * from request_details where request_id=?",nativeQuery=true)
	List<RequestDetails> getRequestDetailsByRequestID(Long requestID);

	@Query(value = "Select date from request_details where request_id=?", nativeQuery = true)
	List<Date> getDatesByID(Long id);


}