package com.aps.repository;


import java.sql.Time;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.aps.domain.ShiftTime;

@Repository
public interface ShiftTimeRepository extends CrudRepository<ShiftTime, Integer> {

	@Query(value = "SELECT * FROM shift_time_details st WHERE st.start_time = ?1", nativeQuery = true)
	List<ShiftTime> getShiftTimeId(Time ts);

}