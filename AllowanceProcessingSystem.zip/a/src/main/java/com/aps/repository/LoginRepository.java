package com.aps.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import com.aps.domain.Login;

public interface LoginRepository extends CrudRepository<Login, String> {

	@Query(value="SELECT password FROM login WHERE corp_id=?1",nativeQuery=true)
	String getValidUser(String corpID);
	
	@Modifying
	@Transactional
	@Query(value="UPDATE login SET password=?2 where corp_id=?1",nativeQuery=true)
	int reset(String corp_id,String password);

	@Query(value="SELECT authorized FROM login where corp_id=?1",nativeQuery=true)
	Boolean authorize(String corp_id);
	
	@Modifying
	@Transactional
	@Query(value="UPDATE login SET authorized=?2 where corp_id=?1",nativeQuery=true)
	int selfDestructing(String corp_id,Boolean value);

	@Query(value = "SELECT * FROM login e WHERE e.corp_id=?1", nativeQuery = true)
	Login checkLogger(String corp_id);

}
