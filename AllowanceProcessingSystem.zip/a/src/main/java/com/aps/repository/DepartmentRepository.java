package com.aps.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.aps.domain.Department;

@Repository
public interface DepartmentRepository extends CrudRepository<Department, String> {
	@Query(value = "SELECT * FROM department where dept_name =?1", nativeQuery = true)
	List<Department> findByName(String departmentName);

	@Query(value = "SELECT * FROM department where dept_code =?1", nativeQuery = true)
	List<Department> findByCode(String departmentCode);

	@Query(value = "SELECT * FROM department where parent_dept_id=?1", nativeQuery = true)
	List<Department> findSubDept(Long departmentId); // here departmentId must
														// be same when clicked
														// expand on frontend

	@Query(value = "SELECT * FROM department d WHERE d.status = 1 AND d.parent_dept_id = -1", nativeQuery = true)
	Iterable<Department> getActiveParentDepartments();

	@Query(value = "SELECT * FROM department d WHERE d.status = 1 AND d.dept_id != -1", nativeQuery = true)
	Iterable<Department> getAllActiveDepartments();

	@Query(value = "SELECT new map(d.departmentCode AS DepartmentCode) FROM department d WHERE d.status= true AND d.departmentId <> ?1 AND d.departmentId <> -1")
	Iterable<Department> getDepartmentCodes(Long departmentId); 
	
	@Query(value = "SELECT * FROM department where dept_id = ?1 limit 1", nativeQuery = true)
	Department findById(Long departmentId);

	@Query(value = "SELECT * FROM department d WHERE d.status = 1 AND d.dept_name = ?1", nativeQuery = true)
	Department getDepartmentByName(String departmentName);

	@Query(value = "SELECT * FROM department d WHERE d.parent_dept_id = -1", nativeQuery = true)
	Iterable<Department> getActiveAndInactiveParentDepartments();

	@Query(value = "SELECT COUNT(*) FROM department d where d.parent_dept_id = ?1", nativeQuery = true)
	int findTotalSubDepartments(int departmentId);

	@Modifying
	@Transactional
	@Query(value = "UPDATE department d SET d.status = '0' WHERE d.dept_id = ?1", nativeQuery = true)
	int deleteDepartment(int departmentId);
	
	@Query(value = "SELECT * FROM department d WHERE d.dept_code = ?1 AND d.status = 1", nativeQuery = true)
	Department getDepartmentDetails(String departmentCode);

}
