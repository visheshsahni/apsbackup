package com.aps.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.aps.domain.Employee;

@Repository
public interface EmployeeRepository extends CrudRepository<Employee, String> {

	@Query(value = "SELECT * FROM employee e WHERE e.corp_id=?1", nativeQuery = true)
	List<Employee> getEmployeeById(String corpId);

	@Query(value = "SELECT * FROM EMPLOYEE where Corp_ID =?1", nativeQuery = true)
	Employee findExistingEmployee(String corp_id);

	@Modifying
	@Transactional
	@Query(value = "UPDATE EMPLOYEE SET emp_name =?1, dept_id=?2, manager_id=?3,"
			+ "role=?4, email_id =?5, benefit_level=?6, phone_no=?7, status=?8,"
			+ " start_date =?9, updated_by=?10, designation=?11 WHERE corp_ID =?12", nativeQuery = true)
	void updateEmployee(String name, Long departmentId, String managerId, String role, String emailId,
			Long benefitLevel, Long phoneNo, boolean status, java.sql.Date startDate, String updatedBy,
			String designation, String corpId2);
	

	@Query(value = "SELECT * FROM employee e WHERE e.corp_id=?1", nativeQuery = true)
	Employee checkUser(String corpID);
	
	@Query(value = "SELECT * FROM employee e WHERE e.dept_id=?1 AND e.status=1", nativeQuery = true)
	List<Employee> getEmployeeByDeptId(Long departmentId);

	@Query(value = "SELECT status FROM employee e WHERE e.corp_id=?1",nativeQuery=true)
	Boolean getStatus(String corpId);

}
