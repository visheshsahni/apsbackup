package com.aps.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aps.domain.Request;
import com.aps.model.DateOfQuarter;
import com.aps.service.RequestService;

@RestController
@RequestMapping("/admin")
public class AdminViewRequestsContoller {

	@Autowired
	private RequestService requestService;

	@GetMapping(path = "/requests/pending")
	public Iterable<Request> getPendingRequests(String status) throws ParseException {
		Date date = new Date();
		Date cycleStartDate = DateOfQuarter.getFirstDateOfQuarter(date);
		Date cycleEndDate = DateOfQuarter.getLastDateOfQuarter(date);
		System.out.println("cstart date"+cycleStartDate);
		System.out.println("cend date"+cycleEndDate);
		return requestService.findRequestsByStatusAndDate(status = "submitted", cycleStartDate, cycleEndDate);
	}

	@GetMapping(path = "/requests/all")
	public Iterable<Request> getApprovedRequests() throws ParseException {
		@SuppressWarnings("unused")
		String status;
		Date date = new Date();
		Date cycleStartDate = DateOfQuarter.getFirstDateOfQuarter(date);
		Date cycleEndDate = DateOfQuarter.getLastDateOfQuarter(date);
		System.out.println("cyclestartdate"+cycleStartDate);
		System.out.println("cycleenddate"+cycleEndDate);
		return requestService.findRequestsByStatusAndDate(status = "approved", cycleStartDate, cycleEndDate);
	}

	@GetMapping(path = "requests/quarterdates")
	public String getFirstDateOfQuarter() throws ParseException {
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		Date startDate = DateOfQuarter.getFirstDateOfQuarter(new Date());
		Date endDate = DateOfQuarter.getLastDateOfQuarter(new Date());

		String jsonString = "{\"startDate\":\"" + dateFormat.format(startDate) + "\",\"endDate\":\""
				+ dateFormat.format(endDate) + "\"}";
		return jsonString;
	}
}
