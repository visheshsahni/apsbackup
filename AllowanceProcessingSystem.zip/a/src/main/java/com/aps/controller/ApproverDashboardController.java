package com.aps.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aps.service.DashboardService;

@RestController
public class ApproverDashboardController {

	@Autowired
	private DashboardService dashboardservice;

	@GetMapping("/dashboard/approver1")
	public Long getPendingRequestsforApprover() {
		return dashboardservice.getPendingRequestforApprover();
	}

	@GetMapping("/dashboard/approver2")
	public Long getShiftAllowanceDaysforApprover() {
		Long data=dashboardservice.getShiftAllowanceDaysforApprover();
		if(data==null){
			return 0l;
		}else
			return data;
	}

	@GetMapping("/dashboard/approver3")
	public Long getOnCallDaysforApprover() {
		Long data=dashboardservice.getOnCallDaysforApprover();
		if(data==null){
			return 0l;
		}else
			return data;
	}

}
