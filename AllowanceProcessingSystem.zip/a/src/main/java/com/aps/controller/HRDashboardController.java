package com.aps.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aps.service.DashboardService;

@RestController
public class HRDashboardController {

	@Autowired
	private DashboardService dashboardservice;

	@GetMapping("/dashboard/hr1")
	public Long getnumberOfDaysDeptID1forHR() {
		Long data=dashboardservice.findnumberOfDaysDeptID1forHR();
		if(data==null){
			return 0l;
		}else
			return data;
	}

	@GetMapping("/dashboard/hr2")
	public Long getnumberOfDaysDeptID2forHR() {
		Long data=dashboardservice.findnumberOfDaysDeptID2forHR();
		if(data==null){
			return 0l;
		}else
			return data;
	}

	@GetMapping("/dashboard/hr3")
	public Long getnumberOfDaysDeptID3forHR() {
		Long data=dashboardservice.findnumberOfDaysDeptID3forHR();
		if(data==null){
			return 0l;
		}else
			return data;
	}

	@GetMapping("/dashboard/hr4")
	public Long getnumberOfDaysDeptID4forHR() {
		Long data=dashboardservice.findnumberOfDaysDeptID4forHR();
		if(data==null){
			return 0l;
		}else
			return data;
	}

	@GetMapping("/dashboard/hr5")
	public Long getnumberOfDaysDeptID5forHR() {
		Long data=dashboardservice.findnumberOfDaysDeptID5forHR();
		if(data==null){
			return 0l;
		}else
			return data;
	}

	@GetMapping("/dashboard/hr6")
	public String getmanagersforManager() {
		return dashboardservice.getmanagerforManager();
	}

}
