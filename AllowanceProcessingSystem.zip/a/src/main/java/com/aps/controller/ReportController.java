package com.aps.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aps.service.DashboardService;
import com.aps.service.RequestService;

@RestController
public class ReportController {
// please refer to dashboard service and repositories for functions
	
	@Autowired
	private DashboardService dashboardservice;

	@GetMapping("/adminReport")
	public List viewReport()
	{
		return dashboardservice.viewReport();
	}
	
}
