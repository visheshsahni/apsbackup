package com.aps.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.aps.domain.Employee;
import com.aps.domain.Login;
import com.aps.model.EmployeeModel;
import com.aps.service.EmployeeService;
import com.aps.service.NotificationService;

@RestController
public class EmployeeController {
	@Autowired
	private EmployeeService employeeservice;
	@Autowired
	private NotificationService notificationService;

	@GetMapping("/employee/v1")
	public List<Employee> getAllEmployee() {
		return employeeservice.getAllEmployee();
	}

	@RequestMapping(value = "/teamreport/{corpId}", method = RequestMethod.GET)
	public List<Employee> getEmployeeUnder(@PathVariable("corpId") String corpId) {

		List<Employee> emp_all = new ArrayList<Employee>();
		List<Employee> emp_under = new ArrayList<Employee>();

		Employee emp=employeeservice.getEmployeeById(corpId);
		
		emp_under.addAll(employeeservice.getEmployeeUnder(emp));
		return emp_under;

	}
	
	

	@PostMapping("/login/v1")
	@ResponseBody
	public Boolean getValidUser(@RequestBody Login login) {
		return employeeservice.getValidUser(login.getCorp_id(), login.getPassword());

	}

	@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST }, value = "/getById/v1")
	public Employee getEmployeeById(String corpId) {

		return employeeservice.getEmployeeById(corpId);
	}

	@RequestMapping("/getById/v1/{corpId}")
	public Employee abc(@PathVariable String corpId) {
		return employeeservice.getEmployeeById(corpId);
	}

	@PostMapping("/validate")
	@ResponseBody
	public String checkUser(@RequestParam(name = "CorpId") String corp_id,@RequestParam(name="value") String value) {
		Employee emp = employeeservice.checkUser(corp_id);
		Login login = employeeservice.checkLogger(corp_id);
		if ((emp == null || login == null) && value.equals("register")) {
			return "Dont Exist";
		} 
		else if ((emp == null || login == null) && value.equals("forgot")) {
			return "Wrong";
		} 
		else if((login.getPassword()!=null) && value.equals("register")){
			return "Redirect to forgot password";
		}
		else if((login.getPassword()!=null && value.equals("forgot"))||(login.getPassword()==null && value.equals("forgot"))||(login.getPassword()==null && value.equals("register"))){
			try {
				System.out.println(emp.getCorpId());
				System.out.println(emp.getEmailId());
				
				notificationService.sendNotification(emp.getEmailId(), emp.getCorpId());
			} catch (MailException e) {
				e.getStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
			return "Mail";
		}
		else{
			return "Error";
		}

	}

	@PostMapping("/reset")
	@ResponseBody
	String reset(@RequestParam(name = "pwd1") String password, @RequestParam(name = "value") String encrypt) {
		String value = Security.decrypt(Security.key, Security.initVector, encrypt);
		String corp_id=value.substring(0, 7);
		String dateCheck=value.substring(7);
		Date date = new Date();
		String cd= new SimpleDateFormat("yyyy-MM-dd").format(date);
		Boolean authorize = employeeservice.authorize(corp_id);
		if (authorize && (cd.equals(dateCheck))) {
			System.out.println("success");
			employeeservice.reset(corp_id, password);
			employeeservice.selfDestructing(corp_id);
			return "Success";
		} else if(!cd.equals(dateCheck)) {
			System.out.println("link");
			return "Link Expired";
		}
		return "Error";
	}

	@PostMapping("/bulkAddEmployee")
	@ResponseStatus(value = HttpStatus.OK)
	public void addEmployeeData(@RequestBody List<EmployeeModel> list_empModel) {

		ArrayList<Employee> list_emp = new ArrayList<Employee>();
		list_emp = employeeservice.getEmployeeObjectList(list_empModel, true);
		employeeservice.checkForDuplicates(list_emp);
	}

	@PostMapping("/updateEmployeeData")
	@ResponseStatus(value = HttpStatus.OK)
	public void updateEmployeeData(@RequestBody EmployeeModel empModel) {

		ArrayList<EmployeeModel> list_empModel = new ArrayList<EmployeeModel>();
		list_empModel.add(empModel);
		ArrayList<Employee> list_emp = new ArrayList<Employee>();
		list_emp = employeeservice.getEmployeeObjectList(list_empModel, false);
		//employeeservice.updateEmployee(list_emp.get(0));
		employeeservice.checkForDuplicates(list_emp);
	}
}
