package com.aps.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aps.service.DashboardService;

@RestController
public class RequesterDashboardController {

	@Autowired
	private DashboardService dashboardservice;

	@GetMapping("/dashboard/requester1")
	public Long getPendingRequestsforRequester() {
		return dashboardservice.getPendingRequestforRequester();
	}

	@GetMapping("/dashboard/requester2")
	public Long getApprovedRequestsforRequester() {
		return dashboardservice.getApprovedRequestforRequester();
	}

	@GetMapping("/dashboard/requester3")
	public Long getRejectedRequestsforRequester() {
		return dashboardservice.getRejectedRequestforRequester();
	}

	@GetMapping("/dashboard/requester4")
	public Long getShiftAllowanceDaysforRequester() {
		Long data=dashboardservice.getShiftAllowanceDaysforRequester();
		if(data==null){
			return 0l;
		}else
			return data;
	}

	@GetMapping("/dashboard/requester5")
	public Long getOnCallDaysforRequester() {
		Long data=dashboardservice.getOnCallDaysforRequester();
		if(data==null){
			return 0l;
		}else
			return data;
	}

}
