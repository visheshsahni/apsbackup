package com.aps.controller;

import java.sql.Time;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.aps.domain.AllowanceType;
import com.aps.domain.Employee;
import com.aps.domain.Request;
import com.aps.domain.RequestDetails;
import com.aps.domain.ShiftTime;
import com.aps.service.AllowanceTypeService;
import com.aps.service.EmployeeService;
import com.aps.service.RequestDetailsService;
import com.aps.service.RequestService;
import com.aps.service.ShiftTimeService;

@RestController
public class RequestController {

	@Autowired
	private RequestService requestservice;
	@Autowired
	private EmployeeService employeeservice;
	@Autowired
	private AllowanceTypeService alltypeservice;

	@Autowired
	private ShiftTimeService shifttimeservice;
	@Autowired
	private RequestDetailsService requestdetailsservice;

	@GetMapping("/request/v1")
	public List<Request> getAllRequest() {
		return requestservice.getAllRequest();
	}

	@PostMapping(value = "/request/v1")
	public void addRequest(@RequestBody(required = true) Request request) {
		requestservice.addRequest(request);
	}


	

	@RequestMapping(value = "/user/{id}", method = RequestMethod.GET)
	public Request getUser(@PathVariable("id") long id) {
		Request request = requestservice.findRequestById(id);
		return request;
	}

	@RequestMapping(value = "/team", method = RequestMethod.POST)
	public List<Request> showTeamReport(@RequestParam(name = "corpId") String corpId,

			@RequestParam(name = "startDate") String startDate, @RequestParam(name = "endDate") String endDate)
			throws ParseException {
		System.out.println(corpId + startDate + endDate);
		String str = startDate;
		SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd yyyy HH:mm:ss");
		Date date;
		date = sdf.parse(str);
		java.sql.Date starttimestamp = new java.sql.Date(date.getTime());


		str = endDate;
		date = sdf.parse(str);
		System.out.println(date);
		java.sql.Date endtimestamp = new java.sql.Date(date.getTime());

		List<Employee> emp = new ArrayList<Employee>();
		Employee emp1 = employeeservice.getEmployeeById(corpId);
		emp = employeeservice.getEmployeeUnder(emp1);

		List<Request> reqList = new ArrayList<Request>();

		for (Employee e : emp) {
			reqList.addAll(requestservice.getTeamReport(e.getCorpId(), starttimestamp, endtimestamp));
		}

		return reqList;

	}

//vishesh
	@GetMapping("/viewReportById/{id}/{month}/{year}")
	public List<Request> viewReport1(@PathVariable("id") String a, @PathVariable String month,
			@PathVariable String year) {
		int monthInt = 0;
		int yearInt = Integer.parseInt(year);
		String[] monthNames = { "January", "February", "March", "April", "May", "June", "July", "August", "September",
				"October", "November", "December" };
		for (int i = 0; i < 12; i++) {
			if (monthNames[i].equalsIgnoreCase(month)) {
				monthInt = i;
			}
		}

		Calendar calendar = Calendar.getInstance();
		Date periodStartDate, periodEndDate;
		calendar.set(Calendar.YEAR, yearInt);
		calendar.set(Calendar.MONTH, monthInt);

		{
			calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMinimum(Calendar.DAY_OF_MONTH));
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			calendar.set(Calendar.MILLISECOND, 0);
			periodStartDate = calendar.getTime();
		}
		{
			calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
			calendar.set(Calendar.HOUR_OF_DAY, 23);
			calendar.set(Calendar.MINUTE, 59);
			calendar.set(Calendar.SECOND, 59);
			calendar.set(Calendar.MILLISECOND, 999);
			periodEndDate = calendar.getTime();

		}
		return requestservice.requesterView1(a, periodStartDate, periodEndDate);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/request/user/v1/{corpId}")
	public List<Request> viewRequests(@PathVariable("corpId") Object a) {
		System.out.println(a.toString());
		return requestservice.requesterView(a.toString());
	}

	@GetMapping("/viewReportById/{id}")
	public List<Request> viewReport(@PathVariable("id") String a) {
		return requestservice.requesterView(a);

	}

	@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST }, value = "/request/update")
	public void addRequest(@RequestParam(name = "corpId") String corpid,
			@RequestParam(name = "requestID") Long requestID, @RequestParam(name = "allowanceType") String alltype,
			@RequestParam(name = "ShiftTime") Long shifttime, @RequestParam(name = "dates") String dates[],
			@RequestParam(name = "button") String status_value) {

		try {

			Employee emplist = employeeservice.getEmployeeById(corpid);
			List<AllowanceType> allowancelist = alltypeservice.getAllowanceTypeByName(alltype);
			Date d = new Date();
			Timestamp sq = new Timestamp(d.getTime());

			Request request = requestservice.findRequestById(requestID);

			// Request request = requestservice.findRequestById(requestID);
			Long typeRate = allowancelist.get(0).getTypeRate();

			System.out.println(requestID);
			request.setAllowanceTypeID(allowancelist.get(0));
			request.setCorpID(emplist);
			request.setNumberOfDays(new Long(dates.length));
			request.setException(true);
			Date currentDate = new Date();
			Timestamp cd = new Timestamp(currentDate.getTime());
			request.setSubmittedDate(cd);
			request.setAmount((dates.length) * typeRate);

			if (status_value.equals("Save")) {
				request.setRequeststatus(Request.request_Status.saved);
			} else {
				request.setRequeststatus(Request.request_Status.submitted);
			}

			/*
			 * Thread.sleep(5000);
			 */
			/*
			 * 
			 * SimpleDateFormat dateFormat = new
			 * SimpleDateFormat("dd-MM-yyyy HH:mm:ss"); final String string =
			 * dateFormat.format(sq); Date parsedDate =
			 * dateFormat.parse(string); Timestamp timestamp = new
			 * java.sql.Timestamp(parsedDate.getTime());
			 * 
			 */
			ShiftTime st;
			List<Request> req = requestservice.getRequestId(corpid);
			Request r = req.get(0);

			if (alltype.equals("Shift Allowance")) {

				Time ppstime = new Time(shifttime);
				List<ShiftTime> shiftTime = shifttimeservice.getShiftTimeId(ppstime);
				st = shiftTime.get(0);
			} else {
				st = null;
			}
			List<RequestDetails> requestDetails = requestdetailsservice.getAllRequestDetailsByRequestID(requestID);
			requestdetailsservice.deleteRequestDetails(requestDetails);

			for (int i = 0; i < dates.length; i++) {
				RequestDetails requestdetails = new RequestDetails();
				requestdetails.setRequestID(r);
				requestdetails.setShiftTimeID(st);
				String startDate = dates[i];
				SimpleDateFormat sdf1 = new SimpleDateFormat("MM/dd/yyyy");
				Date parsed = sdf1.parse(startDate);
				java.sql.Date sql = new java.sql.Date(parsed.getTime());
				requestdetails.setDate(sql);
				requestdetailsservice.addRequestDetails(requestdetails);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// return null;

	}
	// @GetMapping("/request/pending/v1")
	// public Iterable<Request> changeRequests(/* (String a */) {
	// return requestservice.requesterChange("A111112");
	// }
	//
	// @GetMapping(value = "/approver/request/{reqIdString}")
	// public Request getRequestForAction(@PathVariable String reqIdString) {
	// Long reqId = Long.parseLong(reqIdString);
	// return requestservice.findRequestById(reqId);
	// }

	@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST }, value = "/request/add")
	public Boolean addRequest(@RequestParam(name = "corpId") String corpid,
			@RequestParam(name = "allowanceType") String alltype, @RequestParam(name = "ShiftTime") Long shifttime,
			@RequestParam(name = "dates") String dates[], @RequestParam(name = "button") String status_value)
			throws ParseException {

		try {
			Calendar calendar = Calendar.getInstance();
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			Date date = sdf.parse(dates[0]);
			calendar.setTime(date);
			calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMinimum(Calendar.DAY_OF_MONTH));
			Date startDate = calendar.getTime();
			calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
			Date endDate = calendar.getTime();
			Date currentDate = new Date();
			Timestamp sd = new Timestamp(startDate.getTime());
			Timestamp ed = new Timestamp(endDate.getTime());
			Timestamp cd = new Timestamp(currentDate.getTime());
			System.out.println(sd);
			System.out.println(ed);
			Employee emplist = employeeservice.getEmployeeById(corpid);
			List<AllowanceType> allowancelist = alltypeservice.getAllowanceTypeByName(alltype);
			Long typeRate = allowancelist.get(0).getTypeRate();
			String employeeName = emplist.getName();

			Request request = new Request();
			request.setAllowanceTypeID(allowancelist.get(0));
			request.setCorpID(emplist);
			request.setPeriodStartDate(sd);
			System.out.println(request.getPeriodStartDate());
			request.setPeriodEndDate(ed);
			request.setSubmittedDate(cd);
			request.setUpdatedBy(employeeName);
			request.setNumberOfDays(new Long(dates.length));
			request.setAmount((dates.length) * typeRate);
			request.setException(true);

			if (requestservice.getRequest((request.getCorpID()).getCorpId(),
					(request.getAllowanceTypeID()).getAllowanceTypeID(), request.getPeriodStartDate()) == true) {
				if (status_value.equals("Save")) {
					request.setRequeststatus(Request.request_Status.saved);
				} else {
					request.setRequeststatus(Request.request_Status.submitted);
				}
				requestservice.addRequest(request);

				/*
				 * SimpleDateFormat dateFormat = new
				 * SimpleDateFormat("dd-MM-yyyy HH:mm:ss"); final String string
				 * = dateFormat.format(sq); Date parsedDate =
				 * dateFormat.parse(string); Timestamp timestamp = new
				 * java.sql.Timestamp(parsedDate.getTime());
				 */

				ShiftTime st;
				List<Request> req = requestservice.getRequestId(corpid);
				Request r = req.get(0);
				if (alltype.equals("Shift Allowance")) {

					Time ppstime = new Time(shifttime);
					List<ShiftTime> shiftTime = shifttimeservice.getShiftTimeId(ppstime);
					st = shiftTime.get(0);
				} else {
					st = null;
				}

				for (int i = 0; i < dates.length; i++) {
					RequestDetails requestdetails = new RequestDetails();
					requestdetails.setRequestID(r);
					requestdetails.setShiftTimeID(st);
					String userDate = dates[i];
					Date parsed = sdf.parse(userDate);
					java.sql.Date sql = new java.sql.Date(parsed.getTime());
					requestdetails.setDate(sql);
					requestdetailsservice.addRequestDetails(requestdetails);
				}
				return true;

			} else {
				return false;
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();return false;
		}

	}
}
