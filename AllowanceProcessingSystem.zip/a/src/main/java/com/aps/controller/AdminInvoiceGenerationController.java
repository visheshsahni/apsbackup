package com.aps.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aps.domain.Department;
import com.aps.domain.Invoice;
import com.aps.domain.Period;
import com.aps.domain.Request;
import com.aps.model.DashboardModel;
import com.aps.model.GetCurrentYear;
import com.aps.model.SQLDateFormatConverter;
import com.aps.service.DepartmentService;
import com.aps.service.InvoiceService;
import com.aps.service.PeriodService;
import com.aps.service.RequestService;

@RestController
@RequestMapping(value = "/admin")
public class AdminInvoiceGenerationController {

	@Autowired
	private PeriodService periodService;
	@Autowired
	private DepartmentService departmentService;
	@Autowired
	private RequestService requestService;
	@Autowired
	private InvoiceService invoiceService;

	Department departmentObject;
	Invoice invoiceObject;
	Float invoiceAdjustment;

	@GetMapping(path = "/invoice/getYear")
	public JSONObject getCurrentYear() {
		return GetCurrentYear.getYear();
	}

	@GetMapping(path = "/invoice/{year}")
	public Iterable<Period> getPeriodForYear(@PathVariable String year) throws ParseException {
		java.sql.Date sqlDate = SQLDateFormatConverter.convertDate("yyyy", year);
		return periodService.findByYear(sqlDate);
	}

	@GetMapping(path = "/invoice/department")
	public Iterable<Department> getActiveDepartment() {
		return departmentService.getActiveDepartments();
	}

	@PostMapping("/invoice/generate")
	public void generateInvoice(@RequestBody(required = true) String jsonString)
			throws ParseException, org.json.simple.parser.ParseException {
		String invoiceYearString = "";
		String invoicePeriodString = "";
		String invoiceDepartmentString = "";
		String invoiceAdjustmentsString = "";
		String invoiceCommentsString = "";

		JSONParser jsonParser = new JSONParser();
		JSONArray jsonArray = (JSONArray) jsonParser.parse(jsonString);
		invoiceYearString = (String) ((JSONObject) jsonArray.get(0)).get("value");
		invoicePeriodString = (String) ((JSONObject) jsonArray.get(1)).get("value");
		invoiceDepartmentString = (String) ((JSONObject) jsonArray.get(2)).get("value");
		invoiceAdjustmentsString = (String) ((JSONObject) jsonArray.get(3)).get("value");
		if (invoiceAdjustmentsString.equals("")) {
			invoiceAdjustmentsString = "0.0";
		}
		invoiceCommentsString = (String) ((JSONObject) jsonArray.get(4)).get("value");
		if (invoiceCommentsString.equals("")) {
			invoiceCommentsString = "No comments.";
		}

		Long invoiceDepartmentId;
		java.sql.Date invoiceStartDate;
		java.sql.Date invoiceEndDate;
		invoiceAdjustment = Float.valueOf(invoiceAdjustmentsString);
		Float invoiceSum = 0F;
		java.sql.Date invoiceGeneratedDate = SQLDateFormatConverter.convertCurrentDateFormatter("yyyy-MM-dd");

		Period invoicePeriodObject = periodService.getInvoicePeriod(invoiceYearString, invoicePeriodString);
		invoiceStartDate = invoicePeriodObject.getStartDate();
		invoiceEndDate = invoicePeriodObject.getEndDate();

		departmentObject = departmentService.getDepartmentByName(invoiceDepartmentString);
		invoiceDepartmentId = departmentObject.getDepartmentId();

		List<Request> requestsToBeInvoiced = requestService.getRequestsForInvoice(invoiceDepartmentId, invoiceStartDate,
				invoiceEndDate);
		for (Request request : requestsToBeInvoiced) {
			invoiceSum += request.getAmount();
		}

		invoiceObject = new Invoice();
		invoiceObject.setDepartmentID(departmentObject);
		invoiceObject.setPeriodID(invoicePeriodObject);
		invoiceObject.setTotalAmount(invoiceSum);
		invoiceObject.setAdjustments(invoiceAdjustment);
		invoiceObject.setGeneratedDate(invoiceGeneratedDate);
		invoiceObject.setStatus(true);
		invoiceObject.setComments(invoiceCommentsString);
		invoiceObject.setGeneratedBy(DashboardModel.getCorpId());
		invoiceService.save(invoiceObject);

		List<Request> invoicedRequests = new ArrayList<Request>();
		for (Request request : requestsToBeInvoiced) {
			request.setInvoiceID(invoiceObject);
			request.setRequeststatus(Request.request_Status.invoiced);
			request.setUpdatedBy(DashboardModel.getCorpId());
			invoicedRequests.add(request);
		}

		requestService.saveAll(invoicedRequests);
	}

	@GetMapping(value = "/invoice/getreport")
	public List<Object> getGeneratedInvoice() throws ParseException {

		return requestService.getInvoiceReport(departmentObject, invoiceObject);

	}

	@GetMapping(value = "/invoice/getadjustments")
	public String getInvoiceAdjustment() {
		String adjustmentJSON = "{\"adjustment\":" + invoiceAdjustment + "}";
		return adjustmentJSON;
	}

	public Invoice getInvoiceObject() {
		return invoiceObject;
	}
}
