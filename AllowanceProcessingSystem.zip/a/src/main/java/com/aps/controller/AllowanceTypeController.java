package com.aps.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.aps.domain.AllowanceType;
import com.aps.service.AllowanceTypeService;

@RestController
public class AllowanceTypeController {

	@Autowired
	private AllowanceTypeService allowancetypeservice;

	@GetMapping("/allowancetype/v1")
	public List<AllowanceType> getAllAllowanceType() {
		return allowancetypeservice.getAllAllowanceType();
	}
	
	@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST }, value = "/allowancetype/name/v1")
	public List<AllowanceType> getAllowanceByName(String typeName) {
		return allowancetypeservice.getAllowanceTypeByName(typeName);
	}
	
}
