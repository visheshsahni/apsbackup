package com.aps.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.aps.domain.RequestDetails;
import com.aps.service.RequestDetailsService;

@RestController
public class RequestDetailsController {

	@Autowired
	private RequestDetailsService requestdetailsservice;

	@GetMapping("/requestdetails/v1")
	public List<RequestDetails> getAllRequest() {
		return requestdetailsservice.getAllRequestDetails();
	}

	@RequestMapping(value = "/requestdetails/v2/{id}", method = RequestMethod.GET)
	public RequestDetails getRequestDetails(@PathVariable("id") long id) {
		return requestdetailsservice.getRequestDetails(id);
	}

	@RequestMapping(value = "/getDates/{id}", method = RequestMethod.GET)
	public List<Date> getDatesByID(@PathVariable("id") long id) {
		List<Date> d = new ArrayList<>();
		requestdetailsservice.getDatesByID(id).forEach(d::add);
		int a = 0;
		for (Date datee : d) {
			String s = new SimpleDateFormat("MM/dd/yyyy").format(datee);

			try {
				datee = new SimpleDateFormat("MM/dd/yyyy").parse(s);
				d.set(a, datee);
				a++;
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return d;

	}

	@PostMapping(value = "/requestdetails/v1")
	public void addRequest(@RequestBody(required = true) RequestDetails requestdetails) {
		requestdetailsservice.addRequestDetails(requestdetails);
	}

}
