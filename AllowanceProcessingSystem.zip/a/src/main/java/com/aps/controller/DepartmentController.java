package com.aps.controller;

import java.util.List;

import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.aps.domain.Department;
import com.aps.service.DepartmentService;

@RestController

public class DepartmentController {

	@Autowired
	private DepartmentService departmentservice;

	@GetMapping("/department/v1")
	public List<Department> getAllDepartment() {
		return departmentservice.getAllDepartments();
	}

	@GetMapping("departmentByID/{departmentId}")
	public Department getDepartmentById(@PathVariable Long departmentId){
		return departmentservice.findById(departmentId);
		/*return Long.parseLong(departmentId);*/
	}
	@PostMapping("/department/v2")
	public void addDepartment(@RequestBody(required = true) Department dep) {
		// public void addDepartment(@RequestBody(required = true) String
		// department) {

		// ObjectMapper mapper = new ObjectMapper();
		// mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
		// false);
		// List<Department> dep=mapper.readValue(department,new
		// TypeReference<Department>() { });
		departmentservice.addDepartment(dep);

	}

	@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST }, value = "/department/v3")
	public List<Department> findByName(String departmentName) {
		return departmentservice.findByName(departmentName);
	}

	@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST }, value = "/department/v4")
	public List<Department> findByCode(String departmentCode) {
		return departmentservice.findByName(departmentCode);
	}

	@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST }, value = "/department/v5")
	public List<Department> findSubDept(Long departmentId) {
		return departmentservice.findSubDept(departmentId);
	}

	@RequestMapping(method = { RequestMethod.GET }, value = "/department/v6")
	public Iterable<Department> getDepartmentDetails() {
		return departmentservice.getAllActiveDepartments();
	}

	//

	@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST }, value = "/department/id/v1")
	public Department findById(Long deptId) {
		return departmentservice.findById(deptId);
	}

	@RequestMapping("/department/id/v2/{departmentId}")
	public int findTotalSubDepartments(@PathVariable int departmentId) {
		return departmentservice.findTotalSubDepartments(departmentId);
	}

	@RequestMapping(method = { RequestMethod.GET }, value = "/department/id/v4/{departmentId}")
	public Iterable<Department> getDepartmentCodes(@PathVariable Long departmentId) {
		return departmentservice.getDepartmentCodes(departmentId);
	}

	@PostMapping("department/id/v5")
	public void setEmployeeDetails(@RequestBody(required = true) String jsonString) throws ParseException {
		departmentservice.modifyEmployee(jsonString);
	}

}
