package com.aps.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.aps.model.DashboardModel;
import com.aps.service.DashboardService;

@RestController
public class DashboardViewController {

	@Autowired
	private DashboardService dashboardservice;

	@GetMapping("/dashboard/demandsCorpID/{session}")
	public String getCorpIdFromSession(@PathVariable String session) {
		DashboardModel.setCorpId(session);
		return "abc";
	}

	@GetMapping("/dashboard/login1")
	public String getrolesforLogin() {
		return dashboardservice.getroleforLogin();
	}

	@GetMapping("/dashboard/login2")
	public Long getbenefitLevelsforLogin() {
		return dashboardservice.getbenefitLevelforLogin();
	}

	@GetMapping("/dashboard/login3")
	public String getnamesforHeader() {
		return dashboardservice.getnameforHeader();
	}

	@GetMapping("/dashboard/login4")
	public String getdesignationsforHeader() {
		return dashboardservice.getdesignationforHeader();
	}

}
