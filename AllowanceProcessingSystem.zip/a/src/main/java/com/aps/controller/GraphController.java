package com.aps.controller;

import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aps.service.DashboardService;

@RestController
public class GraphController {

	@Autowired
	private DashboardService dashboardservice;

	@GetMapping("/dashboard/graph1")
	public List<Object> getGraphsDataDeptforHR() throws ParseException {
		return dashboardservice.getGraphDataDeptforHR();
	}
}
