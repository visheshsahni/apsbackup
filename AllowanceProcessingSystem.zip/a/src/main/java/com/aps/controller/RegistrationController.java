package com.aps.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.aps.domain.Department;
import com.aps.domain.Employee;
import com.aps.domain.Login;
import com.aps.repository.EmployeeRepository;
import com.aps.service.DepartmentService;
import com.aps.service.EmployeeService;
import com.aps.service.NotificationService;

@RestController
public class RegistrationController {

	@Autowired
	EmployeeRepository employeeRepository;
	@Autowired
	private DepartmentService departmentService;
	@Autowired
	private NotificationService notificationService;
	@Autowired
	private EmployeeService employeeservice;

	public void addEmployee(Employee employee) {
		employeeservice.addEmployee(employee);
	}
	public void addUser(Login login){
		employeeservice.addUser(login);
	}

	@PostMapping("/signup-success")
	public Boolean signupsuccess(@RequestParam(name = "Name") String name, @RequestParam(name = "Email") String email,
			@RequestParam(name = "CorpId") String corpid, @RequestParam(name = "Mobile") Long mobile) {
		// send notification
		try {
			notificationService.sendNotification(email,corpid);
		} catch (MailException e) {
			e.getStackTrace();
			return false;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		Employee employee = new Employee();
		Login login=new Login();
		employee.setCorpId(corpid);
		login.setCorp_id(corpid);
		login.setAuthorizated(true);
		System.out.println(employee.getCorpId());
		employee.setName(name);
		System.out.println(employee.getName());
		employee.setPhoneNo(mobile);
		employee.setEmailId(email);
		employee.setStatus(true);
		employee.setBenefitLevel(0l);
		employee.setDepartmentId(departmentService.findById(1l));
		employee.setManager(employeeRepository.getEmployeeById("A000000").get(0));
		employee.setRole("not hr");
		employee.setUpdatedBy(corpid);
		employee.setDesignation("Hanging");
		
		long millis = System.currentTimeMillis();
		java.sql.Date dateStart = new java.sql.Date(millis);
		employee.setStartDate(dateStart);
		System.out.println(employee.getStartDate());
		addEmployee(employee);
		addUser(login);
		return true;

	}
}
