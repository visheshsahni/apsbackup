package com.aps.controller;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.aps.domain.AllowanceType;
import com.aps.domain.Employee;
import com.aps.domain.Request;
import com.aps.service.AllowanceTypeService;
import com.aps.service.ApproverService;
import com.aps.service.EmployeeService;
import com.aps.service.RequestService;

@RestController
public class ApproverController {

	@Autowired
	private RequestService requestservice;
	@Autowired
	private EmployeeService employeeservice;
	@Autowired
	private ApproverService approverservice;
	@Autowired
	private AllowanceTypeService alltypeservice;

	@RequestMapping(method = RequestMethod.GET, value = "/request/pending/v1/{corpId}")
	public Iterable<Request> changeRequests(@PathVariable String corpId) {
		return approverservice.requestChange(corpId);
	}

	@GetMapping(value = "/approver/request/{reqIdString}")
	public Request getRequestForAction(@PathVariable String reqIdString) {
		Long reqId = Long.parseLong(reqIdString);
		return requestservice.findRequestById(reqId);
	}

	@PostMapping(value = "/statusChange")
	public void getRequestForAction(@RequestParam(name = "requestID") String reqIdString,
			@RequestParam(name = "button") String status_value, @RequestParam(name = "corpIdField") String corpId,
			@RequestParam(name = "allowanceType") String alltype, @RequestParam(name = "days") int days,
			@RequestParam(name = "comments") String comments,@RequestParam(name = "manager") String manager) {
		Long reqId = Long.parseLong(reqIdString);

		try {
			Request request = requestservice.findRequestById(reqId);
			request.setComments(comments);
			Employee emplist = employeeservice.getEmployeeById(corpId);
			Date d = new Date();
			Timestamp sq = new Timestamp(d.getTime());
			request.setStatusStartDate(sq);
			if (emplist.getBenefitLevel() != 10 && emplist.getBenefitLevel() != 14) {
				request.setException(true);
				request.setComments("Exception-Benefit Level");
			}
			request.setUpdatedBy(manager);
			if (status_value.equals("Approve")) {
				request.setRequeststatus(Request.request_Status.approved);
			} else {

				request.setRequeststatus(Request.request_Status.rejected);
			}
			requestservice.update(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
