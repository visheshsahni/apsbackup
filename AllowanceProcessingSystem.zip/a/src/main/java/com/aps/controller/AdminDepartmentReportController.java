package com.aps.controller;

import java.util.Date;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.aps.domain.Department;
import com.aps.domain.Request;
import com.aps.model.GetCurrentYear;
import com.aps.model.MonthDates;
import com.aps.service.DepartmentService;
import com.aps.service.RequestService;

@RestController
@RequestMapping("/admin/report")
public class AdminDepartmentReportController {

	@Autowired
	private DepartmentService departmentSerice;

	@Autowired
	private RequestService requestService;

	String month;
	String year;

	@GetMapping(path = "/department/getYear")
	public JSONObject getCurrentYear() {
		return GetCurrentYear.getYear();
	}

	@GetMapping(path = "/department/getAll")
	public Iterable<Department> getAllDepartments() {
		return departmentSerice.getActiveAndInactiveDepartments();
	}

	@GetMapping(path = "/department/{status}")
	public @ResponseBody List<Object> getDeptReport(@PathVariable String status) {
		Date startDate = MonthDates.getFirstDate(month, year);
		Date endDate = MonthDates.getEndDate(month, year);

		return requestService.getDepartmentReport(startDate, endDate, Request.request_Status.valueOf(status.toLowerCase()));
	}

	@PostMapping(path = "/department/period")
	public void savePeriodData(@RequestBody(required = true) String jsonString) throws ParseException {

		JSONParser jsonParser = new JSONParser();
		JSONArray jsonArray = (JSONArray) jsonParser.parse(jsonString);
		year = (String) ((JSONObject) jsonArray.get(0)).get("value");
		month = (String) ((JSONObject) jsonArray.get(1)).get("value");
	}
}
