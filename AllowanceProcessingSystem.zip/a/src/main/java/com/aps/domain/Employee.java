package com.aps.domain;

import java.sql.Date;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Entity(name = "Employee")
public class Employee {

	@Id
	@Column(name = "corp_id")
	public String corpId;

	@ManyToOne
	@JoinColumn(name = "dept_id")
	public Department departmentId;

	@Column(name = "emp_name")
	public String name;

	@ManyToOne
	// @JsonBackReference
	@JoinColumn(name = "manager_id")
	public Employee manager;

//	@OneToMany(mappedBy="manager")
//	private Set<Employee> subordinates = new HashSet<Employee>();
	
	@Column(name = "email_id")
	public String emailId;
	@Column(name = "role")
	public String role;
	@Column(name = "benefit_level")
	public Long benefitLevel;
	@Column(name = "phone_no")
	public Long phoneNo;
	@Column(name = "status", columnDefinition = "TINYINT(1)")
	private boolean status;

	@Column(name = "start_date")
	public Date startDate;
	@Column(name = "updated_by")
	public String updatedBy;
	@Column(name = "designation")
	public String designation;

	public String getCorpId() {
		return corpId;
	}

	public void setCorpId(String corpId) {
		this.corpId = corpId;
	}

	public Department getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Department departmentId) {
		this.departmentId = departmentId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Employee getManager() {
		return manager;
	}

	public void setManager(Employee manager) {
		this.manager = manager;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Long getBenefitLevel() {
		return benefitLevel;
	}

	public void setBenefitLevel(Long benefitLevel) {
		this.benefitLevel = benefitLevel;
	}

	public Long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public Employee(String corpId, Department departmentId, String name, Employee manager, String emailId, String role,
			Long benefitLevel, Long phoneNo, boolean status, Date startDate, String updatedBy, String designation) {
		super();
		this.corpId = corpId;
		this.departmentId = departmentId;
		this.name = name;
		this.manager = manager;
		this.emailId = emailId;
		this.role = role;
		this.benefitLevel = benefitLevel;
		this.phoneNo = phoneNo;
		this.status = status;
		this.startDate = startDate;
		this.updatedBy = updatedBy;
		this.designation = designation;
	}

	public Employee() {
		super();
	}
}
