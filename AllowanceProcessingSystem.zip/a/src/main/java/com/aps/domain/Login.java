package com.aps.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name = "login")
public class Login {

	@Id
	@Column(name = "corp_id")
	private String corp_id;
	
	@Column(name="password")
	private String password;
	
	@Column(name="authorized")
	private Boolean authorized;

	public Boolean getAuthorized() {
		return authorized;
	}

	public void setAuthorizated(Boolean authorized) {
		this.authorized = authorized;
	}

	public String getCorp_id() {
		return corp_id;
	}

	public void setCorp_id(String corp_id) {
		this.corp_id = corp_id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
