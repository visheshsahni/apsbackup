package com.aps.domain;

public class AllowanceReport {
	private String corpId;
	private String departmentCode;
	private Double amount;

	public AllowanceReport(String corpId, String departmentCode, Double amount) {
		super();
		this.corpId = corpId;
		this.departmentCode = departmentCode;
		this.amount = amount;
	}

	public String getCorpId() {
		return corpId;
	}

	public void setCorpId(String corpId) {
		this.corpId = corpId;
	}

	public String getDepartmentCode() {
		return departmentCode;
	}

	public void setDepartmentCode(String departmentCode) {
		this.departmentCode = departmentCode;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public AllowanceReport() {
		super();
	}

}
