package com.aps.domain;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity(name = "request")
public class Request {

	public static enum request_Status {
		saved, submitted, approved, rejected, invoiced
	};

	@Id
	@Column(name = "request_id", unique = true, nullable = false)
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long requestID;

	@ManyToOne
	@JoinColumn(name = "allowance_type_id")
	private AllowanceType allowanceTypeID;

	@ManyToOne
	@JoinColumn(name = "invoice_id", nullable = true)
	private Invoice invoiceID;

	@ManyToOne
	@JoinColumn(name = "corp_id")
	private Employee corpID;

	@Column(name = "period_start_date")
	private Timestamp periodStartDate;
	@Column(name = "period_end_date")
	private Timestamp periodEndDate;
	@Column(name = "number_of_days")
	private Long numberOfDays;
	@Column(name = "submitted_date")
	private Date submittedDate;

	@Column(name = "request_status", nullable = true)
	@Enumerated(EnumType.STRING)
	private request_Status requeststatus;

	@Column(name = "status_start_date")
	private Timestamp statusStartDate;
	@Column(name = "updated_by")
	private String updatedBy;
	@Column(name = "amount")
	private float amount;
	@Column(name = "comments")
	private String comments;
	@Column(name = "exception", columnDefinition = "TINYINT(1)")
	private boolean isException;

	public Long getRequestID() {
		return requestID;
	}

	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}

	public AllowanceType getAllowanceTypeID() {
		return allowanceTypeID;
	}

	public void setAllowanceTypeID(AllowanceType allowanceTypeID) {
		this.allowanceTypeID = allowanceTypeID;
	}

	public Invoice getInvoiceID() {
		return invoiceID;
	}

	public void setInvoiceID(Invoice invoiceID) {
		this.invoiceID = invoiceID;
	}

	public Employee getCorpID() {
		return corpID;
	}

	public void setCorpID(Employee corpID) {
		this.corpID = corpID;
	}

	public Timestamp getPeriodStartDate() {
		return periodStartDate;
	}

	public void setPeriodStartDate(Timestamp periodStartDate) {
		this.periodStartDate = periodStartDate;
	}

	public Timestamp getPeriodEndDate() {
		return periodEndDate;
	}

	public void setPeriodEndDate(Timestamp periodEndDate) {
		this.periodEndDate = periodEndDate;
	}

	public Long getNumberOfDays() {
		return numberOfDays;
	}

	public void setNumberOfDays(Long numberOfDays) {
		this.numberOfDays = numberOfDays;
	}

	public Date getSubmittedDate() {
		return submittedDate;
	}

	public void setSubmittedDate(Date submittedDate) {
		this.submittedDate = submittedDate;
	}

	public request_Status getRequeststatus() {
		return requeststatus;
	}

	public void setRequeststatus(request_Status requeststatus) {
		this.requeststatus = requeststatus;
	}

	public Timestamp getStatusStartDate() {
		return statusStartDate;
	}

	public void setStatusStartDate(Timestamp statusStartDate) {
		this.statusStartDate = statusStartDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public boolean isException() {
		return isException;
	}

	public void setException(boolean isException) {
		this.isException = isException;
	}

	public Request(Long requestID, AllowanceType allowanceTypeID, Invoice invoiceID, Employee corpID,
			Timestamp periodStartDate, Timestamp periodEndDate, Long numberOfDays, Date submittedDate,
			request_Status requeststatus, Timestamp statusStartDate, String updatedBy, float amount, String comments,
			boolean isException) {
		super();
		this.requestID = requestID;
		this.allowanceTypeID = allowanceTypeID;
		this.invoiceID = invoiceID;
		this.corpID = corpID;
		this.periodStartDate = periodStartDate;
		this.periodEndDate = periodEndDate;
		this.numberOfDays = numberOfDays;
		this.submittedDate = submittedDate;
		this.requeststatus = requeststatus;
		this.statusStartDate = statusStartDate;
		this.updatedBy = updatedBy;
		this.amount = amount;
		this.comments = comments;
		this.isException = isException;
	}

	public Request() {
		super();
	}
}
