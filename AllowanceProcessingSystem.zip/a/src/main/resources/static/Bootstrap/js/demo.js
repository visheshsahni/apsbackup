$('myform').on('submit',function(e) {
e.preventDefault();
  });