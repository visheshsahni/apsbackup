/**
 * 
 */

function sub(){ 
	
	var dates = document.getElementById("#calendar-container").text;
	document.write(dates);
	console.log(dates);
			/*
			var date = new Date(1496809163999);
			var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
			var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);
			var json1;
						  $.getJSON('http://localhost:8100/allowancetypebyname/v1/on call', function(data) {
								var ID = data[0].allowanceTypeID;
								var name = data[0].typeName;
								var rate = data[0].typeRate;
								var flag = data[0].validFlag;
								
								$.getJSON('http://localhost:8100/department/v1', function(json) {
									var dept_id = json[0].departmentId;
									var dept_name = json[0].departmentName;
									var dept_code = json[0].departmentCode;
									var dept_hod = json[0].hod;
									var dept_parent = json[0].parentDepartmentId;
									var dept_desc = json[0].description;
									var dept_status = json[0].status;
									var dept_co =json[0].departmentCordinator;
									
									$.getJSON('http://localhost:8100/employee/v1', function(emp) {
									
										var corp_id = emp[0].corpId;
										var dept = emp[0].departmentId;
										var emp_name = emp[0].name;
										var man = emp[0].manager;
										var email = emp[0].emailId;
										var pass = emp[0].password;
										var role = emp[0].role;
										var bl = emp[0].benefitLevel;
										var phone = emp[0].phoneNo;
										var status = emp[0].status;
										var sdate = emp[0].startDate;
										var edate = emp[0].endDate;
										var upby = emp[0].updatedBy;
										var desig = emp[0].designation;
										
										json1 ="{    \"requestID\": 567,    \"allowanceTypeID\": {      \"allowanceTypeID\": " + ID + ",      \"typeName\": \"" +name+"\",      \"typeRate\": "+rate+",      \"validFlag\":"+flag+"    },    \"invoiceID\": null,    \"corpID\": {      \"corpId\": \""+corp_id+"\",      \"departmentId\": {        \"departmentId\": "+dept_id+",        \"departmentName\": \""+dept_name+"\",         \"departmentCode\": \""+dept_code+"\",        \"hod\": \""+dept_hod+"\",    \"parentDepartmentId\": \""+dept_parent+"\",    \"description\": \""+dept_desc+"\",        \"status\":"+dept_status+",        \"departmentCordinator\": \""+dept_co+"\"       },      \"name\": \""+emp_name+"\",      \"manager\": \""+man+"\",      \"emailId\": \""+email+"\",      \"password\": \""+pass+"\",      \"role\":\""+role+"\",      \"benefitLevel\": \""+bl+"\",      \"phoneNo\": \""+phone+"\",      \"status\": \""+status+"\",      \"startDate\": "+sdate+",      \"endDate\": "+edate+",      \"updatedBy\": \""+upby+"\",      \"designation\": \""+desig+"\"    },    \"periodStartDate\": "+firstDay+",    \"periodEndDate\": "+lastDay+",    \"numberOfDays\": 9,    \"submittedDate\": 978287400000,    \"statusStartDate\": 1496394888000,    \"statusEndDate\": 1496394888000,    \"submittedBy\": \"1\",    \"amount\": 5800,    \"comments\": \"a\",    \"requeststatus\": \"submitted\",  \"exception\": \"true\" }" ;
								  
									document.write(json1); 
									
										
										  $.ajax({
										  
									           type:"POST",
									           url:"http://localhost:8100/request/v1",
									           contentType:"application/json",
									           dataType:"json",
									           data:json1, 
									           
									           error: function(e) {
									        	    console.log(e);},
									           success:function(resultData){
									               alert("Save Complete");
									            //   window.location.replace("http://192.168.85.254:8100/ViewRequests.html");
									           } 
									        	     
									           });  
										
									});
								});
									
						  });
	*/
		}