
$(document).ready(function() {
    window.history.pushState(null, "", window.location.href);
    window.onpopstate = function() {
        window.history.pushState(null, "", window.location.href);
    };
});


$(document).ready(function() {
    window.history.pushState(null, "", window.location.href);        
    window.onpopstate = function() {
        window.history.pushState(null, "", window.location.href);
    };

			var SESSION=Cookies.get('SessionId');
			$('#SESSION').val(SESSION);
			document.getElementById('corpId').value=SESSION;

			var htmlcode;
			var d = new Date();
			var month = new Array();
			month[0] = "January";
			month[1] = "February";
			month[2] = "March";
			month[3] = "April";
			month[4] = "May";
			month[5] = "June";
			month[6] = "July";
			month[7] = "August";
			month[8] = "September";
			month[9] = "October";
			month[10] = "November";
			month[11] = "December";
			var n = month[d.getMonth()];
			var dt=d.getMonth()+1;
			if(dt%3==0) 
				{htmlcode +='<option value="Select">Select</option>';
				htmlcode +='<option value="'+n+'">'+n+'</option>';
				htmlcode +='<option value="'+month[dt-2]+'">'+month[dt-2]+'</option>';
				htmlcode +='<option value="'+month[dt-3]+'">'+month[dt-3]+'</option>';
				}
			 if(dt%3==1)
				 {htmlcode +='<option value="Select">Select</option>';
					htmlcode +='<option value="'+n+'">'+n+'</option>';
				 
				 }
			 if(dt%3==2)
				 {htmlcode +='<option value="Select">Select</option>';
					htmlcode +='<option value="'+n+'">'+n+'</option>';
					htmlcode +='<option value="'+month[dt-2]+'">'+month[dt-2]+'</option>';
					
				 }
			$('#Month').html(htmlcode);
			
			$('#calendar-container').multiDatesPicker({
				minDate: 0, // today
				maxDate: 0 // +30 days from today
			}); 
			
			$('#Month').change(function()
			{
				
				$('#calendar-container').multiDatesPicker('resetDates','picked');
				var date=new Date();
				var year = date.getFullYear();
				var selectedText=$(this).find(':selected').text();
				var month= new Date(Date.parse(selectedText +" 1,"+year)).getMonth()+1;
				console.log(month);
			
				 /* var calendar; */
				/*  
				 var mind=new Date();
				 var maxd=new Date();
				  */
				var firstDay = new Date(year, month - 1, 1);
				var lastDay = new Date(year, month , 0);
				console.log(firstDay + lastDay);
				
				var firstDate = firstDay.getDate();
				var lastDate;
				
				if(month == (date.getMonth()+1))
				{
					lastDate = date.getDate();
				}
				else
				{
					lastDate = lastDay.getDate();
				}
				console.log(firstDate +" "+ lastDate);
				
				 var minda =(month>9 ? '' : '0')+ month +"/"+(firstDate>9 ? '' : '0')+firstDate+ "/"+ date.getFullYear();
				 var maxda =(month>9 ? '' : '0')+ month +"/"+(lastDate>9 ? '' : '0')+lastDate+"/"+ date.getFullYear();
				
				 console.log(minda +" "+ maxda);
				 
				 $('#calendar-container').multiDatesPicker('destroy');
				 $('#calendar-container').multiDatesPicker({
						minDate: minda, 
						maxDate: maxda 
					}); 
				
				});
				//code for dynamically showing and removing shift time based on allowance type selection
				$("#st").hide();
				$("#allowanceType").change(function() {
					var selectedVal = $(this).find(':selected').val();
					var selectedText = $(this).find(':selected').text();
					if (selectedText == "Shift Allowance") {
						$("#st").show();
					} else
						$("#st").hide();	
				});
			
			});

