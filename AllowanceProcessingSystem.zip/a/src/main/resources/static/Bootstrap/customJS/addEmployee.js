jQuery(document).ready(
	function($){

		$('#submit').click(function (e)
			
		{
			e.preventDefault();
			var blankFields = []; //Variable to store Blank element location
			var flag = 1;
			$("input[type=file]").parse(
			{
				config:
				{
					delimiter: ",",
					header: true,
					dynamicTyping: false,
					skipEmptyLines: false,
					complete: function (result, file)
					{
						//console.log("This file done:", file);
						//......................................................        
						// console.log(result.data[0]["Corp_ID"]); //Printing the JSON stringified data
						//THIS CODE BELOW HAS TO BE USED FOR VALIDATION ON EMPLOYEE CSV FILE
						for (var i = 0; i < result.data.length; i++)
						{
							if (result.data[i]["corpId"] == "")
							{
								blankFields.push(i + 2);
								result.data.splice(i, 1);
							}
						}
						for (var i = 0; i <= result.data.length; i++)
						{
							if (result.data.length == 0)
							{
								$("#error").html("Empty File!");
								flag = 0;
							}
						}
						if (blankFields.length > 0)
						{
							$("#error").html("Caught blank element at" + blankFields + " row in the excel sheet");
						}
						var emp = (JSON.stringify(result.data)); //Variable to store parsed CSV JSON stringified data
						//console.log(emp);
						//console.log("Caught blank element at " + blankFields + " rows in the excel sheet");
						//......................................................   
						//AJAX QUERY TO POST DATA
						

						$.ajax({
							type: "POST",
							url: "/bulkAddEmployee",
							    // The key needs to match your method's input parameter (case-sensitive).
							    data: emp ,
							    contentType: "application/json; charset=utf-8",
							    success: function(data){
							    	sweetAlert("Bulk Add Employees successful!", "success")
							    },
							    error: function(errMsg) {
							    	sweetAlert("Error Uploading employee data!", "error")
							   }
							});
					}
				}
			});
		});
		
	});