$(document).ready(function(){
		function get(name){
			   if(name=(new RegExp('[?&]'+encodeURIComponent(name)+'=([^&]*)')).exec(location.search))
			      return decodeURIComponent(name[1]);
			}

		var SESSION=Cookies.get('SessionId');
		$('#SESSION').val(SESSION);
		document.getElementById('corpId').value=SESSION;
		
		var month=get('month');
		
		var year=get('year');
		
		var firstDate = new Date(year,(month-1),1);
		var lastDate = new Date(year,(month),0);
		
		document.getElementById('startDate').value = firstDate;
		document.getElementById('endDate').value = lastDate;
		console.log(firstDate);console.log(lastDate);
		var formData = $('form').serializeArray();
		console.log(formData);
		  $.ajax({
		       type: 'post',
		       url: '/team',
		       data: formData,
		       success: function (resultData) {console.log("hi1");
		    	   
		    	   	var empName = " ";
		    	   	var onCallDays = "0";
	   				var onCallAmount = "0";
	   				var shiftDays = "0";
	   				var shiftAmount = "0";
	   				var onCallStatus= "N/A";
	   				var shiftStatus = "N/A ";
	   				
	   				$.each(resultData, function(i, item) {console.log(item);
        				if(i == 0) {console.log("hi");console.log(corpId);
        					empName = item.corpID.name;
    	   					if(item.allowanceTypeID.typeName == "On call Allowance") {
        						onCallDays = item.numberOfDays;
        						onCallAmount = item.amount;
        						onCallStatus = item.requeststatus;
        					} else if(item.allowanceTypeID.typeName = "Shift Allowance") {
        						shiftDays = item.numberOfDays;
        						shiftAmount = item.amount;
        						shiftStatus = item.requeststatus;
        					console.log("loop");}
    						
        				} else {
        					if(empName == item.corpID.name) {
        						
        	   					if(item.allowanceTypeID.typeName == "On call Allowance") {
            						onCallDays = item.numberOfDays;
            						onCallAmount = item.amount;
            						onCallStatus = item.requeststatus;
            					} else if(item.allowanceTypeID.typeName = "Shift Allowance") {
            						shiftDays = item.numberOfDays;
            						shiftAmount = item.amount;
            						shiftStatus = item.requeststatus;
            					}
        						
        	   					$('<tr>').append($('<td>').text(empName),
        			    				$('<td>').text(onCallDays),
        			    				$('<td>').text(onCallAmount),
        			    				$('<td>').text(onCallStatus),
        			    				$('<td>').text(shiftDays),
        			    				$('<td>').text(shiftAmount),
        			    				$('<td>').text(shiftStatus)).appendTo('#report_table');
        						
        	   				 empName = " ";
    			    	   	 onCallDays = "0";
    		   				 onCallAmount = "0";
    		   				 shiftDays = "0";
    		   				 shiftAmount = "0";
    		   				 onCallStatus= "N/A";
    		   				 shiftStatus = "N/A ";console.log("loop1");
    		   				 
        					} else {
        						if(empName != " ") {
        						$('<tr>').append($('<td>').text(empName),
        			    				$('<td>').text(onCallDays),
        			    				$('<td>').text(onCallAmount),
        			    				$('<td>').text(onCallStatus),
        			    				$('<td>').text(shiftDays),
        			    				$('<td>').text(shiftAmount),
        			    				$('<td>').text(shiftStatus)).appendTo('#report_table');
        						
        						 empName = " ";
        			    	   	 onCallDays = "0";
        		   				 onCallAmount = "0";
        		   				 shiftDays = "0";
        		   				 shiftAmount = "0";
        		   				 onCallStatus= "N/A";
        		   				 shiftStatus = "N/A ";console.log("loop2");
        						}
        						
        	    				empName = item.corpID.name;
        	   					if(item.allowanceTypeID.typeName == "On call Allowance") {
            						onCallDays = item.numberOfDays;
            						onCallAmount = item.amount;
            						onCallStatus = item.requeststatus;
            					} else if(item.allowanceTypeID.typeName = "Shift Allowance") {
            						shiftDays = item.numberOfDays;
            						shiftAmount = item.amount;
            						shiftStatus = item.requeststatus;
            					}
        						
        					}
        				}});
        				 if(empName != " ") {
        					 console.log("loop3");
        					$('<tr>').append($('<td>').text(empName),
    			    				$('<td>').text(onCallDays),
    			    				$('<td>').text(onCallAmount),
    			    				$('<td>').text(onCallStatus),
    			    				$('<td>').text(shiftDays),
    			    				$('<td>').text(shiftAmount),
    			    				$('<td>').text(shiftStatus)).appendTo('#report_table');
    					} 
        				
	   				
		       }
		     }); 

		});