$(document).ready(
                function() {
                      var SESSION=Cookies.get('SessionId');
                      if((Cookies.get('SessionId'))===undefined)
                        {
                        window.location.href ="/index.html";
                        }


        document.getElementById('labelId').innerText=SESSION

        var settings = {
            "async": true,
            "crossDomain": true,
            "url": "http://localhost:8100/dashboard/demandsCorpID/" + SESSION,
            "method": "GET",
            "headers": {
                "content-type": "application/x-www-form-urlencoded",
                "cache-control": "no-cache"
            },
        }

        $.ajax(settings).done(function (response) {

        });

        var settings = {
              "async": true,
              "crossDomain": true,
              "url": "http://localhost:8100/dashboard/hr6",
              "method": "GET",
              "headers": {
                "cache-control": "no-cache",
                "postman-token": "865103b9-ef36-4a7b-92f1-7ab779af1531"
              }
            }

            $.ajax(settings).done(function (response) {
              if (response!=0) {//------------------visibility for Team Report

              document.getElementById("report").style.display = "block";
              document.getElementById("teamrep").style.display = "block";
              }
            });

        var settings = {
              "async": true,
              "crossDomain": true,
              "url": "http://localhost:8100/dashboard/login1",
              "method": "GET",
              "headers": {
                "cache-control": "no-cache",
                "postman-token": "8481411f-7271-e610-1761-e5d36dee4271"
              }
            }

            $.ajax(settings).done(function (response) {

            if (response=="hr"){//------------------visibility for HR

                document.getElementById("aprmenu").style.display = "block";
               document.getElementById("hrviewreq").style.display = "block";
               document.getElementById("deptrep").style.display = "block";
               document.getElementById("emprep").style.display = "block";
               document.getElementById("hrmenuinvoice").style.display = "block";
               document.getElementById("hrmenumanagedept").style.display = "block";
               document.getElementById("hrmenumanageemp").style.display = "block";
               document.getElementById("hr").style.display = "block";
               document.getElementById("report").style.display = "block";
               document.getElementById("hrgraph").style.display = "block";
               document.getElementById("userviewreq").style.display="none";
              // document.getElementsByTagName("a[href='http://localhost:8100/request.html']").style.display="none";

            }
            else {
                var settings = {
                      "async": true,
                      "crossDomain": true,
                      "url": "http://localhost:8100/dashboard/login2",
                      "method": "GET",
                      "headers": {
                        "cache-control": "no-cache",
                        "postman-token": "1c3f2c55-23dd-54d1-b785-a4f440693723"
                      }
                    }

                    $.ajax(settings).done(function (response) {
                        if(response==10||response==14||!response) {//------------------visibility for requester
                        	document.getElementById("req").style.display = "block";
                        }
                        else {//------------------------------visibility for approver

                    document.getElementById("aprmenu").style.display = "block";
                    document.getElementById("req").style.display = "block";
                    document.getElementById("app").style.display = "block";
                        }
                    });
            }
            });

                var html_code1 = '';
                $.getJSON('http://localhost:8100/dashboard/requester1', function(data) {
                    html_code1 +=data;
                    $('#rpr').html(html_code1);
                });

                var html_code2 = '';
                $.getJSON('http://localhost:8100/dashboard/requester2', function(data) {
                    html_code2 +=data;
                    $('#rar').html(html_code2);
                });

                var html_code3 = '';
                $.getJSON('http://localhost:8100/dashboard/requester3', function(data) {
                    html_code3 +=data;
                    $('#rrr').html(html_code3);
                });

                var html_code4 = '';
                $.getJSON('http://localhost:8100/dashboard/requester4', function(data) {
                    html_code4 +=data;
                    $('#rsa').html(html_code4);
                });

                var html_code5 = '';
                $.getJSON('http://localhost:8100/dashboard/requester5', function(data) {
                    html_code5 +=data;
                    $('#roc').html(html_code5);
                });

                var html_code6 = '';
                $.getJSON('http://localhost:8100/dashboard/approver1', function(data) {
                    html_code6 +=data;
                    $('#apr').html(html_code6);
                });

                var html_code7 = '';
                $.getJSON('http://localhost:8100/dashboard/approver2', function(data) {
                    html_code7 +=data;
                    $('#asa').html(html_code7);
                });

                var html_code8 = '';
                $.getJSON('http://localhost:8100/dashboard/approver3', function(data) {
                    html_code8 +=data;
                    $('#aoc').html(html_code8);
                });

                var html_code9 = '';
                $.getJSON('http://localhost:8100/dashboard/hr1', function(data) {
                    html_code9 +=data;
                    $('#dept1').html(html_code9);
                });

                var html_code10 = '';
                $.getJSON('http://localhost:8100/dashboard/hr2', function(data) {
                    html_code10 +=data;
                    $('#dept2').html(html_code10);
                });

                var html_code11 = '';
                $.getJSON('http://localhost:8100/dashboard/hr3', function(data) {
                    html_code11 +=data;
                    $('#dept3').html(html_code11);
                });

                var html_code12 = '';
                $.getJSON('http://localhost:8100/dashboard/hr4', function(data) {
                    html_code12 +=data;
                    $('#dept4').html(html_code12);
                });

                var html_code13 = '';
                $.getJSON('http://localhost:8100/dashboard/hr5', function(data) {
                    html_code13 +=data;
                    $('#dept5').html(html_code13);
                });

                var settings = {
                  "async": true,
                  "crossDomain": true,
                  "url": "http://localhost:8100/dashboard/login3",
                  "method": "GET",
                  "headers": {
                    "cache-control": "no-cache",
                    "postman-token": "1d48fd54-a91e-b440-18b6-6037a75532e5"
                  }
                }

                $.ajax(settings).done(function (response) {
                  $('#name').html(response);
                });

                var settings = {
                  "async": true,
                  "crossDomain": true,
                  "url": "http://localhost:8100/dashboard/login4",
                  "method": "GET",
                  "headers": {
                    "cache-control": "no-cache",
                    "postman-token": "16a13d7b-e917-70fe-4195-88d652787e92"
                  }
                }

                $.ajax(settings).done(function (response) {
                  $('#desig').html(response);
                });
            });