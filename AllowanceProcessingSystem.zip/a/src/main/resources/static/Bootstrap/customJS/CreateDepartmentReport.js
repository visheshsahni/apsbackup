 $(document).ready(
 	function() {
 		var currentYear;
 		var previousYear;

 		$.getJSON("http://localhost:8100/admin/report/department/getYear",
 			function(json) {
 				currentYear = json.year;
 				previousYear = currentYear - 1;

 				var addYear = '<option value="' + currentYear + '">' + currentYear + '</option>';
 				addYear += '<option value="' + previousYear + '">' + previousYear + '</option>';
 				var dropdownYear = $('#ReportYear');
 				$(dropdownYear).append(addYear);
 			});

 		$.getJSON("http://localhost:8100/admin/report/department/getAll",
 			function(json) {
 				var htmlCodeDepartment = "";
 				var dropdown = $('#DepartmentName');
 				dropdown.empty();
 				$(function() {
 					htmlCodeDepartment += '<option value="">Select</option>';
 					$.each(json,
 						function(i, item) {
 							var value = item.departmentName;
 							htmlCodeDepartment += '<option value="' + value + '">' + value + '</option>';
 						});
 				});
 				$(dropdown).append(htmlCodeDepartment);
 			});
 	});

 function ClearField() {
 	document.getElementById("ReportYear").value = "";
 	document.getElementById("ReportPeriod").value = "";
 	document.getElementById("DepartmentName").value = "";
 };

 function GenerateReport() {
 	var formData = $("form").serializeArray();
 	$.ajax({
 		type: "POST",
 		url: "http://localhost:8100/admin/report/department/period",
 		data: JSON.stringify(formData),
 		contentType: "application/json",
 		dataType: "json"
 	});

 	window.location.href = "/ViewDepartmentReportPage.html";
 };