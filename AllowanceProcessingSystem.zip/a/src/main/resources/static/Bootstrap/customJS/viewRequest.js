
$(document).ready(function() {
	var SESSION=Cookies.get('SessionId');
	$('#SESSION').val(SESSION);
	document.getElementById('corpId').value=SESSION;
    window.history.pushState(null, "", window.location.href);        
    window.onpopstate = function() {
   	window.history.pushState(null, "", window.location.href);
    };
    
    var corpId =document.getElementById('corpId').value;
    console.log(corpId);
    $.getJSON("http://localhost:8100/request/user/v1/"+corpId, function(json) {
    $(function() 
   	{
     	$.each(json, function(i, item) {
        var t1 = new Date(item.periodStartDate);
        var index = t1.getMonth();
        
		var t2 = new Date(item.submittedDate);
		var submittedDate = (t2.getDate() < 10) ? "0" + t2.getDate() : t2.getDate();
		var submittedMonth = ((t2.getMonth()+1) < 10) ? "0" + (t2.getMonth()+1) : (t2.getMonth()+1);
		var submittedYear = t2.getFullYear();
		var submitted = submittedDate + "-" +submittedMonth + "-" +submittedYear;

		var month = new Array();
		month[0] = "January";
		month[1] = "February";
		month[2] = "March";
		month[3] = "April";
		month[4] = "May";
		month[5] = "June";
		month[6] = "July";
		month[7] = "August";
		month[8] = "September";
		month[9] = "October";
		month[10] = "November";
		month[11] = "December";
		
		var id=item.requestID;

        $('<tr id='+i+'>').append($('<td>').text(i+1),
        $('<td>').text(item.allowanceTypeID.typeName),
        $('<td>').text(month[index]),      
        $('<td>').text(item.numberOfDays),
        $('<td>').text(item.requeststatus),
        $('<td>').text(submitted),
	    $('<td>').text(item.comments),
        $('<td>').html("<a href=editrequest.html?rid="+id+">View / Edit</a>"),
        $('<td hidden>').text(item.requestID)
                 	).appendTo('#records_table');					
         });
       	});
    });
});
