$(document).ready(function()
{
  $("#getEmployeeBtn").attr('disabled', 'disabled');
  var $regexname = /(A|a)[0-9]{6}/;
  $('#corpId').on('keypress keydown keyup', function()
  {
    if (!$(this).val().match($regexname))
    {
      // there is a mismatch, hence show the error message
      $("#getEmployeeBtn").attr('disabled', 'disabled');
    }
    else
    {
      // else, do not display message
      $("#getEmployeeBtn").removeAttr('disabled');
    }
  });
  var options = "";
  $.ajax(
  {
    url: "http://localhost:8100/department/v6",
    method: "GET",
    dataType: 'JSON',
    success: function(returnObj)
    {
      for (var i = 0; i < returnObj.length; i++)
      {
        options += "<option>" + returnObj[i].departmentId + "</option>";
      }
      $("#departmentId").append(options);
    }
  });
});

  function getEmployee()

{

  var inputCorpId = document.getElementById('corpId').value;

  var settings = {
    "async": true,
    "crossDomain": true,
    "url": "http://localhost:8100/getById/v1/" + inputCorpId,
    "method": "GET",
    "headers":
    {
      "content-type": "application/x-www-form-urlencoded",
      "cache-control": "no-cache"
    },
  }

  $.ajax(settings).done(function(response)
  {
    //console.log(JSON.stringify(response,null,4));
    var l = Object.keys(response).length;
    $('#error').css("visibility", "hidden");
    //console.log(l);
    //............................................................................................
    function compareValue()
    {

      var select = document.getElementById("departmentId");
      var x = select.options.length;
      for (var i = 0; i < x; i++)
      {
        var deptId = document.getElementById("departmentId").options[i].value;
        if (deptId == response.departmentId.departmentId)
        {
          select.options[i].selected = true;
        }
      }
    }
    if (!(l <= 0))
    {

      $('#updateEmp').css("visibility", "visible");
      $('#empName').val(response.name);
      if (response.manager == null)
      {
        $('#managerId').val(response.manager);
      }
      else
      {
        $('#managerId').val(response.manager.corpId);
      }
      $('#emailId').val(response.emailId);
      if (response.role == "hr")
      {
        $('#role').val('1');
      }
      else if (response.role == "not hr")
      {
        $('#role').val('2');
      }

      $('#benefitLevel').val(response.benefitLevel);
      compareValue();

      $('#phoneNo').val(response.phoneNo);
      $('#designation').val(response.designation);

      if (response.status == true)
      {
        $('#status').val('1');
      }
      else if (response.status == false)
      {
        $('#status').val('2');
      }
    }
    else if (l == 0)
    {
      $('#updateEmp').css("visibility", "hidden");
      $('#error').html("No such record exists");
      $('#error').css("visibility", "visible");
    }
    //............................................................................................                
  });
}




function sub()
{

  var name = document.getElementById("empName").value;
  var managerId = document.getElementById("managerId").value;
  var emailId = document.getElementById("emailId").value;
  var r = document.getElementById("role");
  var role = r.options[r.selectedIndex].text;
  var benefitLevel = document.getElementById("benefitLevel").value;
  var phoneNo = document.getElementById("phoneNo").value;
  var designation = document.getElementById("designation").value;
  var d = document.getElementById("departmentId");
  var departmentId = d.options[d.selectedIndex].text;
  var corpId = document.getElementById("corpId").value;
  var e = document.getElementById("status");
  var status = e.options[e.selectedIndex].text;



  var json1 = {};
  json1["corpId"] = corpId;
  json1["departmentId"] = departmentId;
  json1["name"] = name;
  json1["managerId"] = managerId;
  json1["emailId"] = emailId;
  json1["role"] = role;
  json1["benefitLevel"] = benefitLevel;
  json1["phoneNo"] = phoneNo;
  json1["status"] = status;
  json1["designation"] = designation;


  var json = JSON.stringify(json1);

  //console.log(json);
  $.ajax(
  {
    type: "POST",
    url: "/updateEmployeeData", //enter the endpoint here
    contentType: "application/json; charset=utf-8",
    data: json,
    error: function(e)
    {
      //console.log(e);
    },
    success: function(resultData)
    {
      sweetAlert("Employee Update successful!", "success")
      $('#updateEmp').css("visibility", "hidden");
    }
  });

}