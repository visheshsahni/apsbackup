
$(document).ready(function() {
	var SESSION=Cookies.get('SessionId');
	$('#SESSION').val(SESSION);
	document.getElementById('corpId').value=SESSION;
    window.history.pushState(null, "", window.location.href);        
    window.onpopstate = function() {
   	window.history.pushState(null, "", window.location.href);
    };
    
    var corpId =document.getElementById('corpId').value;
    $.getJSON("http://localhost:8100/request/pending/v1/"+corpId, function(json) {
    $(function() 
   	{
        $.each(json, function(i, item) {
        	var t1 = new Date(item.periodStartDate);
			var startDate = (t1.getDate() < 10) ? "0" + t1.getDate() : t1.getDate();
			var startMonth = ((t1.getMonth()+1) < 10) ? "0" + (t1.getMonth()+1) : (t1.getMonth()+1);
			var startYear = t1.getFullYear();
			var formattedStartDate = startDate + "-" +startMonth + "-" +startYear;
			var t2 = new Date(item.periodEndDate);
			var endDate = (t2.getDate() < 10) ? "0" + t2.getDate() : t2.getDate();
			var endMonth = ((t2.getMonth()+1) < 10) ? "0" + (t2.getMonth()+1) : (t2.getMonth()+1);
			var endYear = t2.getFullYear();
			var formattedEndDate = endDate + "-" +endMonth + "-" +endYear;
			var requestStatus=item.requeststatus;
			var id=item.requestID;

		 $('<tr id='+id+'>').append($('<td>').text(item.corpID.corpId), 
                 $('<td>').text(item.corpID.name), 
                $('<td>').text(item.allowanceTypeID.typeName),
                $('<td>').text(formattedStartDate),
                $('<td>').text(formattedEndDate),
                $('<td>').text(item.numberOfDays),
                $('<td>').text(item.requeststatus),
               $('<td>').html("<a href=changeRequest.html?rid="+id+"><input class='btn-success btn' type=submit value=Action></input></a>"),
               $('<td hidden>').text(item.requestID)
            	).appendTo(
                '#records_table');			
         });
       	});
    });
});
