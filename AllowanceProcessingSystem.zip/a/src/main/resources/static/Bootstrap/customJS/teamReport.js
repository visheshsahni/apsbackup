$(document).ready(
		function() {$.getJSON( "http://localhost:8100/admin/report/department/getYear",
         		function(json) {
     		currentYear = json.year;
       		previousYear = currentYear - 1;

     		var addYear = '<option value="' + currentYear + '">' + currentYear + '</option>';
     		addYear += '<option value="' + previousYear + '">' + previousYear + '</option>';
     		$('#Year').html(addYear);
   		});
			
		});
function doSomething()
{		$(this).disabled = true;


var month=$("#Month").find(':selected').val();

		
		var year=$("#Year").find(':selected').text();
		
		
			   window.location.href = "/report.html?month="+month+"&year="+year;
		
	}
