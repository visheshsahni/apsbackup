$(document).ready(
	function() {
		getReport();
	});

function getReport() {
	var reportType = $('#ReportType :selected').text();
	$('#report_table tbody').empty();

	$.getJSON("http://localhost:8100/admin/report/department/" + reportType, function(json) {
		var departmentName = " ";
		var onCallDays = " ";
		var onCallAmount = " ";
		var shiftDays = " ";
		var shiftAmount = " ";
		var rowTotal = 0.0;
		var grandTotal = 0.0;

		$(function() {

			$.each(json, function(i, item) {
				if (i == 0) {
					departmentName = item.DepartmentName;
					if (item.AllowanceType == "On call Allowance") {
						onCallDays = item.NumberOfDays;
						onCallAmount = item.Amount;
						rowTotal += item.Amount;
					} else if (item.AllowanceType = "Shift Allowance") {
						shiftDays = item.NumberOfDays;
						shiftAmount = item.Amount;
						rowTotal += item.Amount;
					}
				} else {
					if (departmentName == item.DepartmentName) {
						if (item.AllowanceType == "On call Allowance") {
							onCallDays = item.NumberOfDays;
							onCallAmount = item.Amount;
							rowTotal += item.Amount;
						} else if (item.AllowanceType = "Shift Allowance") {
							shiftDays = item.NumberOfDays;
							shiftAmount = item.Amount;
							rowTotal += item.Amount;
						}

						$('<tr>').append($('<td>').text(departmentName),
							$('<td>').text(onCallDays),
							$('<td>').text(onCallAmount),
							$('<td>').text(shiftDays),
							$('<td>').text(shiftAmount),
							$('<td>').text(rowTotal)).appendTo('#report_table');

						departmentName = " ";
						onCallDays = " ";
						onCallAmount = " ";
						shiftDays = " ";
						shiftAmount = " ";
						grandTotal += rowTotal;
						rowTotal = 0.0;
					} else {

						if (departmentName != " ") {
							$('<tr>').append($('<td>').text(departmentName),
								$('<td>').text(onCallDays),
								$('<td>').text(onCallAmount),
								$('<td>').text(shiftDays),
								$('<td>').text(shiftAmount),
								$('<td>').text(rowTotal)).appendTo('#report_table');
						}

						departmentName = " ";
						onCallDays = " ";
						onCallAmount = " ";
						shiftDays = " ";
						shiftAmount = " ";
						grandTotal += rowTotal;
						rowTotal = 0.0;

						departmentName = item.DepartmentName;
						if (item.AllowanceType == "On call Allowance") {
							onCallDays = item.NumberOfDays;
							onCallAmount = item.Amount;
							rowTotal += item.Amount;
						} else if (item.AllowanceType = "Shift Allowance") {
							shiftDays = item.NumberOfDays;
							shiftAmount = item.Amount;
							rowTotal += item.Amount;
						}
					}
				}

			});

			if (departmentName != " ") {
				$('<tr>').append($('<td>').text(departmentName),
					$('<td>').text(onCallDays),
					$('<td>').text(onCallAmount),
					$('<td>').text(shiftDays),
					$('<td>').text(shiftAmount),
					$('<td>').text(rowTotal)).appendTo('#report_table');
			}

			grandTotal += rowTotal;
			rowTotal = 0.0;

			$('<tr style="font-weight:bold">').append($('<td colspan="5">').text("Total Amount"),
				$('<td>').text(grandTotal)).appendTo('#report_table');

			grandTotal = 0.0;
		});
	});
}