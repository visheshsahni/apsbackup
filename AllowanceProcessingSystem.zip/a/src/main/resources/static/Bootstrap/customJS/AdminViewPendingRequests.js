$.getJSON("http://localhost:8100/admin/requests/pending", function(json) {
	$(function() {
		$.each(json, function(i, item) {
			$('<tr>').append($('<td>').text(item.corpID.corpId),
				$('<td>').text(item.corpID.name),
				$('<td>').text(item.corpID.benefitLevel),
				$('<td>').text(item.corpID.manager.name),
				$('<td>').text(item.allowanceTypeID.typeName),
				$('<td>').text(item.numberOfDays),
				$('<td>').text(item.amount),
				$('<td>').text(item.requeststatus)).appendTo('#records_table');
		});
	});

	showQuarterDates();
});

function showQuarterDates() {
	$.getJSON("http://localhost:8100/admin/requests/quarterdates", function(json) {
		var period = "Period : " + json.startDate + " - " + json.endDate;
		document.getElementById("QuarterDates").innerHTML = period;
	});

}