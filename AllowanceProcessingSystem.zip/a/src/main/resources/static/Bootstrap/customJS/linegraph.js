$(document).ready(function(){

var settings = {
				  "async": true,
				  "crossDomain": true,
				  "url": "http://localhost:8100/dashboard/graph1",
				  "method": "GET",
				  "headers": {
				    "cache-control": "no-cache",
				    "postman-token": "1198e9e4-3c17-d60d-f44b-dfed54c15538"
				  }
				}

				$.ajax(settings).done(function (response) {

				  var periodid = [];
				  var deptid = [];
				  var amount = [];
				  var bamount = [];
				  var camount = [];
				  var damount = [];
				  var eamount = [];

                       for(var i in response){

					  deptid.push(response[i].did);
                       }



				  for(var i in response){


					  if(deptid[i]==1){
					  amount.push(response[i].ta);
					  }

					  else if(deptid[i]==2){
						  bamount.push(response[i].ta);
					  }


					  else if(deptid[i]==6){
						  camount.push(response[i].ta);
					  }


					  else if(deptid[i]==7){
						  damount.push(response[i].ta);
					  }


					  else if(deptid[i]==8){
						  eamount.push(response[i].ta);
					  }


				  }

				  for(var i in response){

					  if(deptid[i]==1){
						  var date= response[i].pyear;
						  var formattedDate = date.split('-');
						var xaxis=response[i].pid+'-'+formattedDate[0];
						  periodid.push(xaxis);
					  
					  }
					  
				  }







			var chartdata = {

					labels: periodid,
					datasets: [
						{
							label: "Retail",
							fill: false,
							lineTension: 0.1,
							backgroundcolor: "rgba(59, 89, 152 #FFFFFF)",
							borderColor: '#dc143c',
							pointHoverBackgroundColor: "rgba(255,0,0,1)",

							pointHoverBorderColor: "rgba(255,0,0,1)",
							data: amount
						},
						{
							label: "ISFA",
							fill: false,
							lineTension: 0.1,
							backgroundcolor: "rgba(59, 89, 152 #FFFFFF)",
							borderColor: '#4169e1',

							pointHoverBackgroundColor: "rgba(59, 89, 152, 1)",
							pointHoverBorderColor: "rgba(59, 89, 152, 1)",
							data: bamount
						},
						{
							label: "Central",
							fill: false,
							lineTension: 0.1,
							backgroundcolor: "rgba(59, 89, 152 #FFFFFF)",
							borderColor: '#663399',

							pointHoverBackgroundColor: '#663399',
							pointHoverBorderColor: '#663399',
							data: camount
						},
						{
							label: "DC",
							fill: false,
							lineTension: 0.1,
							backgroundcolor: "rgba(59, 89, 152 #FFFFFF)",
							borderColor: '#3cb371',

							pointHoverBackgroundColor: "rgba(0, 128, 0, 1)",
							pointHoverBorderColor: "rgba(59, 89, 152, 1)",
							data: damount
						},
						{
							label: "TIS",
							fill: false,
							lineTension: 0.1,
							backgroundcolor: "rgba(59, 89, 152 #FFFFFF)",
							borderColor: '#ffd700',

							pointHoverBackgroundColor: "rgba(255, 140, 0, 1)",
							pointHoverBorderColor: "rgba(59, 89, 152, 1)",
							data: eamount
						}


							]




			};
			var ctx =$("#mycanvas");

			var LineGraph = new Chart(ctx, {
				type: 'line',
				data: chartdata
			});

	});
});