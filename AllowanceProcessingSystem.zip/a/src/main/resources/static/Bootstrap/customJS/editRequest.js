$(document).ready(
		
		function() 
		{
			var SESSION=Cookies.get('SessionId');
			$('#SESSION').val(SESSION);
			document.getElementById('corpId').value=SESSION;
			var startdate;
			var enddate;
			var minda;
			var maxda;
			function get(name)
			{
				   if(name=(new RegExp('[?&]'+encodeURIComponent(name)+'=([^&]*)')).exec(location.search))
				      return decodeURIComponent(name[1]);
			}
		
			var requestID=get('rid');
			
			$("#requestID").val(requestID);
			$.getJSON("http://localhost:8100/user/"+requestID, function(json){
				
				var a=json.allowanceTypeID.typeName;
				var status = json.requeststatus;
				
				startdate=new Date(json.periodStartDate);
				enddate=new Date(json.periodEndDate);				
				var month=startdate.getMonth()+1;
				var date = new Date();
				var firstDay = new Date(startdate.getFullYear(), month - 1, 1);
				var lastDay = new Date(startdate.getFullYear(), month , 0);
							
				if(month == (date.getMonth()+1))
				{
					lastDay = date.getDate();
				}
				else
				{
					lastDay = enddate.getDate();
				}
				
				/* date=JSON.parse(json.periodStartDate); */
				
				 minda =(month>9 ? '' : '0')+ month +"/01/"+ date.getFullYear();
				 maxda =(month>9 ? '' : '0')+ month +"/"+(lastDay>9 ? '' : '0')+lastDay+"/"+ date.getFullYear();
				
				$.getJSON('http://localhost:8100/getDates/'+requestID, function(data){
					
					$( "#calendar-container" ).multiDatesPicker({ 
				    	addDates: data,
				    	minDate: minda, // today
				    	maxDate: maxda,
				    	
				    });
					if((status=='submitted')||(status=='invoiced')||(status=='approved'))
					{
						$('#corpId').prop('readonly',true);
						$('#allowanceType').attr('disabled',true);
						$('#ShiftTime').attr('disabled',true);
						$('#submit').hide();
						$('#save').hide();
						$( "#calendar-container" ).multiDatesPicker('destroy');
						$( "#calendar-container" ).multiDatesPicker({ 
					    	addDates: data,
					    	minDate: minda, // today
					    	maxDate: maxda,
					    	beforeShowDay: function (date) {
					            var min = new Date(minda);
					          	var max = new Date(maxda);
					            if (date.getMonth() === min.getMonth())
					            {
					            	if (date.getDate() >= min.getDate() && date.getDate() <= max.getDate())
					            	{
					                  return [false, ''];
					               }
					            }
					            return [true, ''];
					       }

					    	
					    });
						
					}
					
				});
				
				var html_code1 = '';
				$.getJSON('http://localhost:8100/allowancetype/v1', function(data) {
					
					html_code1 += '<option value="">Select</option>';
					$.each(data, function(key, value) {
						if(value.typeName==a){
						html_code1 += '<option value="'+value.typeName+'" selected>'
								+ value.typeName + '</option>';
								
								if(value.typeName=='Shift Allowance')
									{
										$("#st").show();
									}
						}
						else
							{
							html_code1 += '<option value="'+value.typeName+'">'
							+ value.typeName + '</option>';
							}

					});
					
					$('#allowanceType').html(html_code1);
					
				});
			
			$.getJSON("http://localhost:8100/requestdetails/v2/"+requestID,function(json){
				var a=null, b=null;
				if((json.shiftTimeID)!=null)
				{
					a=json.shiftTimeID.startTime;
					b=json.shiftTimeID.endTime;
				}

				var html_code2 = '';
				$.getJSON('http://localhost:8100/shifttime/v1', function(data) {
					var t1 = new Date(a);console.log("hi");
					var startHours = (t1.getHours() < 10) ? "0" + t1.getHours() : t1.getHours();
					var startMinutes = (t1.getMinutes() < 10) ? "0" + t1.getMinutes() : t1.getMinutes();
					var formattedStartTime1 = startHours + ":" + startMinutes;
					
					var t2 = new Date(a);
					var endHours = (t2.getHours() < 10) ? "0" + t2.getHours() : t2.getHours();
					var endMinutes = (t2.getMinutes() < 10) ? "0" + t2.getMinutes() : t2.getMinutes();
					var formattedEndTime1 = endHours + ":" + endMinutes;
					$.each(data, function(key, value) {
						var t1 = new Date(value.startTime);
						var startHours = (t1.getHours() < 10) ? "0" + t1.getHours() : t1.getHours();
						var startMinutes = (t1.getMinutes() < 10) ? "0" + t1.getMinutes() : t1.getMinutes();
						var formattedStartTime = startHours + ":" + startMinutes;
						
						var t2 = new Date(value.endTime);
						var endHours = (t2.getHours() < 10) ? "0" + t2.getHours() : t2.getHours();
						var endMinutes = (t2.getMinutes() < 10) ? "0" + t2.getMinutes() : t2.getMinutes();
						var formattedEndTime = endHours + ":" + endMinutes;
						
						if((formattedStartTime==formattedStartTime1)&&(formattedEndTime==formattedEndTime1))
						{html_code2 += '<option value="'+value.startTime+'" selected >'
								+ formattedStartTime + " - "+ formattedEndTime + '</option>';}
						else
							{
							html_code2 += '<option value="'+value.startTime+'" >'
							+ formattedStartTime + " - "+ formattedEndTime + '</option>';
							}

					});
					$('#ShiftTime').append(html_code2);
				});
				
			})
			
			 
			})
		
			$("#st").hide();
			
			$("#allowanceType").change(function() {
				var selectedVal = $(this).find(':selected').val();
				var selectedText = $(this).find(':selected').text();
				if (selectedText == "Shift Allowance") {
					$("#st").show();
				} else
					$("#st").hide();

			});
			
			
		});
