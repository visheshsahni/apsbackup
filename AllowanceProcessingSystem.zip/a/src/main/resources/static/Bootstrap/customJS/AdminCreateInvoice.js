$(document).ready(
	function() {

		$("#CreateInvoiceButton").attr('disabled', 'disabled');
		var $regexname = /^\d+(\.?\d)?$/;
		
		function updateFormEnabled() {
		    if (verifyForm()) {
		    	$("#CreateInvoiceButton").removeAttr('disabled');
		    } else {
		        $('#CreateInvoiceButton').attr('disabled', 'disabled');
		    }
		}
		function verifyForm() {
			var temp = $("#DepartmentName").val();
		    if ($('#DepartmentName').val() != "None" && $('#InvoicePeriod').val() != "None" && $('#AdjustmentsField').val().match($regexname)) {
		        return true;
		    } else {
		        return false
		    }
		}

		$("#InvoicePeriod").change(updateFormEnabled);
		$("#DepartmentName").change(updateFormEnabled);
		$('#AdjustmentsField').on('keyup', function() {
			updateFormEnabled();
		});

		var currentYear;
		var previousYear;

		$.getJSON("http://localhost:8100/admin/invoice/getYear",
			function(json) {
				currentYear = json.year;
				previousYear = currentYear - 1;

				var addYear = '<option value="' + currentYear + '">' + currentYear + '</option>';
				addYear += '<option value="' + previousYear + '">' + previousYear + '</option>';
				var dropdownYear = $('#InvoiceYear');
				$(dropdownYear).append(addYear);
			});

		$("#InvoiceYear").change(
			function() {
				var selectedVal = $(this).find(':selected').val();
				var selectedText = $(this).find(':selected').text();
				if (selectedText == currentYear || selectedText == previousYear) {
					$("#AdjustmentsDiv").show();
					$("#CommentsDiv").show();
					$("#ButtonsDiv").show();

					$("#InvoicePeriodDiv").show();
					$.getJSON("http://localhost:8100/admin/invoice/" + selectedText,
						function(json) {
							var htmlCodePeriod = "";
							var dropdown = $('#InvoicePeriod');
							dropdown.empty();
							$(function() {
								htmlCodePeriod += '<option value="None" selected>Select</option>';
								$.each(json,
									function(i, item) {
										var value = item.periodName;
										htmlCodePeriod += '<option value="' + value + '">' + value + '</option>';
									});
							});

							$(dropdown).append(htmlCodePeriod);
						});

					$('#DepartmentNameDiv').show();
					$.getJSON("http://localhost:8100/admin/invoice/department",
						function(json) {
							var htmlCodeDepartment = "";
							var dropdown = $('#DepartmentName');
							dropdown.empty();
							$(function() {
								htmlCodeDepartment += '<option value="None" selected>Select</option>';
								$.each(json,
									function(i, item) {
										var value = item.departmentName;
										htmlCodeDepartment += '<option value="' + value + '">' + value + '</option>';
									});
							});
							$(dropdown).append(
								htmlCodeDepartment);
						});
				} else {
					$('#InvoicePeriodDiv').hide();
					$('#DepartmentNameDiv').hide();
					$('#AdjustmentsDiv').hide();
					$('#CommentsDiv').hide();
					$('#ButtonsDiv').hide();
				}
			});
	});

function ClearField() {
	document.getElementById("AdjustmentsField").value = "";
	document.getElementById("CommentsField").value = "";
	$('#InvoicePeriod').val('None');
	$('#DepartmentName').val('None');
	$("#CreateInvoiceButton").attr('disabled', 'disabled');
};

function CreateInvoice() {
	var formData = $("form").serializeArray();
	$.ajax({
		type: "POST",
		url: "http://localhost:8100/admin/invoice/generate",
		data: JSON.stringify(formData),
		contentType: "application/json",
		dataType: "json"
	});

	window.location.href = "/AdminInvoiceReport.html";
};