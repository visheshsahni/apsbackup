$(document).ready(getDepartments);

function getDepartments()
{
  var settings = {
    "async": true,
    "crossDomain": true,
    "url": "http://localhost:8100/department/v6",
    "method": "GET",
    "headers":
    {
      "cache-control": "no-cache"
    }
  }
  $.ajax(settings).done(function(returnObj)
  {
    var l = Object.keys(returnObj).length;
    var rowCount = 0;
    //console.log(l);
    //............................................................................................
    if (l <= 0)
    {
      $('#error').html("No Department Found");
    }
    else
    {
      $("#department_table tbody tr").remove();
      var table = document.getElementById("department_table");
      for (var i = 0; i < l; i++)
      {
        rowCount++;
        var row = table.insertRow(0);
        row.id = 'id' + rowCount;
        $(row).append(
          $('<td>').text(returnObj[i].departmentId),
          $('<td>').text(returnObj[i].departmentName),
          $('<td>').text(returnObj[i].departmentCode),
          $('<td>').text(returnObj[i].hod),
          $('<td>').text(returnObj[i].description),
          $('<td>').text(returnObj[i].departmentCordinator),
          $('<td>').html(' <input class="btn btn-danger" id="delete" name="delete" style="visibility: hidden;" type="button" value="Delete" onClick="deleteDepartment(this)">')
        ).appendTo('#department_table_body');
      }
      $("#department_table, #delete").css("visibility", "visible");
    }
    //............................................................................................		            
  });
}
var departmentId;
var departmentName;

function deleteDepartment(x)
{
  departmentId = $('td:first', $(x).parents('tr')).text();
  departmentName = $('td:nth-child(2)', $(x).parents('tr')).text();
 // console.log(departmentId);
  var settings = {
    "async": true,
    "crossDomain": true,
    "url": "http://localhost:8100/department/id/v2/" + departmentId,
    "method": "GET",
    "headers":
    {
      "content-type": "application/x-www-form-urlencoded",
      "cache-control": "no-cache"
    },
  }
  $.ajax(settings).done(function(response)
  {
   // console.log(response);
    //............................................................................................
    if (response != 0)
    {
      sweetAlert("Sorry!","Cannot delete the department. Delete it's subdepartments first.!", "error");
    }
    else
    {
      var options = '';
      $("#deptList").empty();
      var settings = {
        "async": true,
        "crossDomain": true,
        "url": "http://localhost:8100/department/id/v4/" + departmentId,
        "method": "GET",
        "headers":
        {
          "cache-control": "no-cache"
        }
      }
      $.ajax(settings).done(function(response)
      {
        for (var i = 0; i < response.length; i++)
        {
          options += "<option>" + response[i].DepartmentCode + "</option>";
        }
        $("#deptList").append(options);
      });
      $('#newdeptModal').modal("show");
    }
    //............................................................................................		            
  });
}

function updateEmployees()
{
  var d = document.getElementById("deptList");
  var departmentCode = d.options[d.selectedIndex].text;
  var dataObj = {};
  dataObj["departmentId"] = departmentId;
  dataObj["departmentCode"] = departmentCode;
  var data = JSON.stringify(dataObj);
  var settings = {
    "async": true,
    "crossDomain": true,
    "url": "http://localhost:8100/department/id/v5",
    "method": "POST",
    "headers":
    {
      "content-type": "application/json",
      "cache-control": "no-cache"
    },
    "processData": false,
    "data": data
  }
  $.ajax(settings).done(function(response)
  {
    sweetAlert(departmentName, "Deleted successfully!", "success")
    //location.reload();
  });
}